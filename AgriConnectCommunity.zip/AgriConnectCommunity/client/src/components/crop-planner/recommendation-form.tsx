import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const recommendationSchema = z.object({
  soilType: z.string().min(1, "Please select a soil type"),
  rainfallLevel: z.string().min(1, "Please select a rainfall level"),
  landSize: z.coerce.number().min(0.1, "Land size must be at least 0.1 hectares"),
  temperature: z.string().min(1, "Please select a temperature range"),
  irrigationAccess: z.string().min(1, "Please select irrigation availability"),
  farmingExperience: z.string().min(1, "Please select your farming experience"),
});

type RecommendationFormValues = z.infer<typeof recommendationSchema>;

export default function RecommendationForm() {
  const { toast } = useToast();
  
  const form = useForm<RecommendationFormValues>({
    resolver: zodResolver(recommendationSchema),
    defaultValues: {
      soilType: "",
      rainfallLevel: "",
      landSize: 1,
      temperature: "",
      irrigationAccess: "",
      farmingExperience: "",
    },
  });
  
  const getRecommendationMutation = useMutation({
    mutationFn: async (data: RecommendationFormValues) => {
      const res = await apiRequest("POST", "/api/crop-recommendations", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crop-recommendations"] });
      toast({
        title: "Success",
        description: "Crop recommendations have been generated.",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to generate recommendations: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: RecommendationFormValues) => {
    getRecommendationMutation.mutate(data);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="soilType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Soil Type</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select soil type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="clay">Clay</SelectItem>
                  <SelectItem value="sandy">Sandy</SelectItem>
                  <SelectItem value="loamy">Loamy</SelectItem>
                  <SelectItem value="silty">Silty</SelectItem>
                  <SelectItem value="peaty">Peaty</SelectItem>
                  <SelectItem value="chalky">Chalky</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="rainfallLevel"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Annual Rainfall</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select rainfall level" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="low">Low (less than 600mm)</SelectItem>
                  <SelectItem value="medium">Medium (600-1200mm)</SelectItem>
                  <SelectItem value="high">High (more than 1200mm)</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="landSize"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Land Size (hectares)</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  min="0.1" 
                  step="0.1" 
                  {...field} 
                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="temperature"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Average Temperature</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select temperature range" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="cool">Cool (below 15°C)</SelectItem>
                  <SelectItem value="moderate">Moderate (15-25°C)</SelectItem>
                  <SelectItem value="warm">Warm (25-35°C)</SelectItem>
                  <SelectItem value="hot">Hot (above 35°C)</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="irrigationAccess"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Irrigation Availability</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select irrigation access" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="none">None (Rain-fed only)</SelectItem>
                  <SelectItem value="limited">Limited (Basic irrigation)</SelectItem>
                  <SelectItem value="good">Good (Regular irrigation)</SelectItem>
                  <SelectItem value="excellent">Excellent (Advanced systems)</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="farmingExperience"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Farming Experience</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your experience level" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="beginner">Beginner (0-2 years)</SelectItem>
                  <SelectItem value="intermediate">Intermediate (3-5 years)</SelectItem>
                  <SelectItem value="experienced">Experienced (6-10 years)</SelectItem>
                  <SelectItem value="expert">Expert (10+ years)</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button
          type="submit"
          className="w-full"
          disabled={getRecommendationMutation.isPending}
        >
          {getRecommendationMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            "Get Recommendations"
          )}
        </Button>
      </form>
    </Form>
  );
}
