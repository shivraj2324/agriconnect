import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Sun, CloudRain, CloudDrizzle, Wind } from "lucide-react";

interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  icon: string;
  windSpeed: number;
  humidity: number;
  forecast: string;
}

export default function WeatherWidget() {
  const { toast } = useToast();
  const [location, setLocation] = useState<string>("");

  // Get user's location coordinates
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation(`${position.coords.latitude},${position.coords.longitude}`);
        },
        (error) => {
          console.error("Error getting location:", error);
          // Default to a central location if geolocation fails
          setLocation("28.6139,77.2090"); // New Delhi coordinates
        }
      );
    } else {
      setLocation("28.6139,77.2090"); // Default to New Delhi if geolocation not supported
    }
  }, []);

  // Fetch weather data
  const { data: weather, isLoading } = useQuery<WeatherData>({
    queryKey: ["/api/weather", location],
    enabled: !!location,
    refetchInterval: 1800000, // Refetch every 30 minutes
    onError: (error) => {
      toast({
        title: "Weather data unavailable",
        description: `Could not fetch weather data: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Function to get the weather icon
  const getWeatherIcon = (condition: string) => {
    const conditionLower = condition.toLowerCase();
    if (conditionLower.includes("sun") || conditionLower.includes("clear")) {
      return <Sun className="h-10 w-10 text-yellow-500" />;
    } else if (conditionLower.includes("rain")) {
      return <CloudRain className="h-10 w-10 text-blue-500" />;
    } else if (conditionLower.includes("drizzle") || conditionLower.includes("shower")) {
      return <CloudDrizzle className="h-10 w-10 text-blue-400" />;
    } else {
      return <Sun className="h-10 w-10 text-yellow-500" />;
    }
  };

  // Mock weather data for when the API has not returned yet or if there's an error
  const mockWeather: WeatherData = {
    location: "Pune, Maharashtra",
    temperature: 32,
    condition: "Sunny",
    icon: "sun",
    windSpeed: 5,
    humidity: 45,
    forecast: "Good day for irrigation. Plan harvesting for early morning."
  };

  // Use mock data only while loading, otherwise use API data
  const displayWeather = isLoading ? mockWeather : weather || mockWeather;

  return (
    <Card>
      <CardContent className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row items-center justify-between">
          <div className="mb-4 sm:mb-0 text-center sm:text-left">
            <h3 className="text-lg font-medium text-neutral-900">Current Weather</h3>
            <p className="text-sm text-neutral-500">{displayWeather.location}</p>
          </div>

          <div className="flex items-center">
            {getWeatherIcon(displayWeather.condition)}
            <div className="ml-4">
              <p className="text-2xl font-bold">{displayWeather.temperature}°C</p>
              <p className="text-sm text-neutral-500">
                {displayWeather.condition}, Wind: {displayWeather.windSpeed} km/h
              </p>
            </div>
          </div>

          <div className="hidden md:block h-16 w-px bg-neutral-200 mx-6"></div>

          <div className="mt-4 sm:mt-0 text-center sm:text-left">
            <div className="flex items-center">
              <Wind className="h-4 w-4 mr-2 text-primary" />
              <h4 className="text-sm font-medium text-neutral-900">Recommendation</h4>
            </div>
            <p className="text-sm text-neutral-500 mt-1">{displayWeather.forecast}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
