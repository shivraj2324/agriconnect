import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Product } from "@shared/schema";
import { ArrowUpIcon, TrendingUp, LineChart, DollarSign, ShoppingCart } from "lucide-react";

// Simple responsive chart from recharts
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";

interface SalesAnalyticsProps {
  products: Product[];
}

export default function SalesAnalytics({ products }: SalesAnalyticsProps) {
  // Calculate total sales
  const totalSales = useMemo(() => {
    return products.reduce((sum, product) => {
      // In a real app, we would use actual sales data
      // Here we're using a simple estimation based on product price and a presumed sales rate
      const estimatedSales = product.price * (product.quantity * 0.2);
      return sum + estimatedSales;
    }, 0);
  }, [products]);
  
  // Calculate total orders (simplified)
  const totalOrders = useMemo(() => {
    return Math.floor(products.length * 2.5);
  }, [products]);
  
  // Find top selling product
  const topSellingProduct = useMemo(() => {
    if (products.length === 0) return null;
    
    return products.reduce((top, product) => {
      const currentSales = product.price * (product.quantity * 0.2);
      const topSales = top.price * (top.quantity * 0.2);
      
      return currentSales > topSales ? product : top;
    }, products[0]);
  }, [products]);
  
  // Calculate top selling product percentage
  const topSellingPercentage = useMemo(() => {
    if (!topSellingProduct || totalSales === 0) return 0;
    
    const topSales = topSellingProduct.price * (topSellingProduct.quantity * 0.2);
    return Math.round((topSales / totalSales) * 100);
  }, [topSellingProduct, totalSales]);
  
  // Mock data for charts
  const monthlySalesData = [
    { name: 'Jan', sales: 4200 },
    { name: 'Feb', sales: 3800 },
    { name: 'Mar', sales: 5100 },
    { name: 'Apr', sales: 4800 },
    { name: 'May', sales: 6200 },
    { name: 'Jun', sales: 7800 },
    { name: 'Jul', sales: 8200 },
    { name: 'Aug', sales: 8400 },
    { name: 'Sep', sales: 9100 },
    { name: 'Oct', sales: 8700 },
    { name: 'Nov', sales: 9800 },
    { name: 'Dec', sales: 12400 },
  ];
  
  const categorySalesData = [
    { name: 'Vegetables', sales: 12500 },
    { name: 'Fruits', sales: 9800 },
    { name: 'Grains', sales: 18500 },
    { name: 'Dairy', sales: 5800 },
    { name: 'Equipment', sales: 8200 },
  ];
  
  const productDistributionData = [
    { name: 'Organic', value: 65 },
    { name: 'Non-Organic', value: 35 },
  ];
  
  const COLORS = ['#2F855A', '#48BB78', '#68D391', '#9AE6B4', '#C6F6D5'];
  const PIE_COLORS = ['#2F855A', '#EBF4FF'];
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Total Sales</p>
              <div className="flex items-center">
                <DollarSign className="mr-2 h-4 w-4 text-muted-foreground" />
                <p className="text-2xl font-bold">₹{totalSales.toLocaleString()}</p>
              </div>
              <p className="flex items-center text-sm text-green-600">
                <ArrowUpIcon className="mr-1 h-4 w-4" />
                <span>12% from last month</span>
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
              <div className="flex items-center">
                <ShoppingCart className="mr-2 h-4 w-4 text-muted-foreground" />
                <p className="text-2xl font-bold">{totalOrders}</p>
              </div>
              <p className="flex items-center text-sm text-green-600">
                <ArrowUpIcon className="mr-1 h-4 w-4" />
                <span>5% from last month</span>
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Top Selling Product</p>
              <p className="text-xl font-bold">{topSellingProduct?.name || "N/A"}</p>
              <p className="text-sm text-muted-foreground">
                {topSellingPercentage}% of total sales
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="mr-2 h-5 w-5" />
              Sales Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={monthlySalesData}
                  margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2F855A" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#2F855A" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 12 }}
                    tickLine={false}
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }} 
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `₹${value}`}
                  />
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <Tooltip formatter={(value) => [`₹${value}`, 'Sales']} />
                  <Area 
                    type="monotone" 
                    dataKey="sales" 
                    stroke="#2F855A" 
                    fillOpacity={1}
                    fill="url(#colorSales)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Sales by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={categorySalesData}
                    margin={{ top: 5, right: 10, left: 10, bottom: 5 }}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis type="number" tickFormatter={(value) => `₹${value / 1000}K`} />
                    <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} width={80} />
                    <Tooltip formatter={(value) => [`₹${value}`, 'Sales']} />
                    <Bar dataKey="sales" fill="#2F855A">
                      {categorySalesData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Product Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-center">
                <ResponsiveContainer width="50%" height="100%">
                  <PieChart>
                    <Pie
                      data={productDistributionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={70}
                      fill="#8884d8"
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      labelLine={false}
                    >
                      {productDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value}%`, '']} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-col space-y-2 w-1/2">
                  {productDistributionData.map((item, index) => (
                    <div key={index} className="flex items-center">
                      <div 
                        className="w-3 h-3 mr-2 rounded-full" 
                        style={{ backgroundColor: PIE_COLORS[index % PIE_COLORS.length] }}
                      />
                      <span className="text-sm">{item.name}: {item.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
