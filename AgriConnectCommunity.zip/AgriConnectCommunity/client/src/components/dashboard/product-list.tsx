import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Wheat, Apple, Sprout, Loader2 } from "lucide-react";

interface ProductListProps {
  products: Product[];
  isLoading: boolean;
  onEdit: (product: Product) => void;
  onRefresh: () => void;
}

export default function ProductList({ products, isLoading, onEdit, onRefresh }: ProductListProps) {
  const { toast } = useToast();
  const [deletingProductId, setDeletingProductId] = useState<number | null>(null);
  
  const getProductIcon = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'grains':
        return <Wheat className="h-5 w-5" />;
      case 'fruits':
        return <Apple className="h-5 w-5" />;
      default:
        return <Sprout className="h-5 w-5" />;
    }
  };
  
  const deleteProductMutation = useMutation({
    mutationFn: async (productId: number) => {
      await apiRequest("DELETE", `/api/products/${productId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Product deleted",
        description: "Your product has been successfully deleted.",
      });
      onRefresh();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete product: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleDelete = (productId: number) => {
    setDeletingProductId(productId);
  };
  
  const confirmDelete = () => {
    if (deletingProductId) {
      deleteProductMutation.mutate(deletingProductId);
      setDeletingProductId(null);
    }
  };
  
  const cancelDelete = () => {
    setDeletingProductId(null);
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <Sprout className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">No products yet</h3>
          <p className="text-muted-foreground text-center mt-2">
            Add your first product to start selling on the marketplace.
          </p>
          <Button onClick={() => onEdit({ id: 0 } as Product)} className="mt-4">
            Add Your First Product
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Products</CardTitle>
        <CardDescription>Manage your listings and track sales</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => (
                <TableRow key={product.id}>
                  <TableCell>
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 bg-primary/20 rounded-full flex items-center justify-center text-primary">
                        {getProductIcon(product.category)}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium">{product.name}</div>
                        <div className="text-sm text-muted-foreground">{product.description}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">₹{product.price} / {product.unit}</div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{product.quantity} {product.unit}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={product.quantity > 10 ? "default" : "outline"} className="bg-green-100 text-green-800 hover:bg-green-100">
                      {product.quantity > 10 ? "Active" : "Low Stock"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => onEdit(product)}
                      >
                        Edit
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-red-600 hover:text-red-800"
                        onClick={() => handleDelete(product.id)}
                      >
                        Delete
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      <AlertDialog 
        open={deletingProductId !== null} 
        onOpenChange={(open) => !open && cancelDelete()}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to delete this product?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The product will be permanently removed from your listings.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteProductMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
