import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { ForumTopic } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { 
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Heart, MessageSquare, Plus } from "lucide-react";

interface ForumListProps {
  topics: ForumTopic[];
  isLoading: boolean;
  onSelectTopic: (topic: ForumTopic) => void;
}

const newTopicSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters").max(100, "Title must be less than 100 characters"),
  content: z.string().min(20, "Content must be at least 20 characters"),
  tags: z.string().min(1, "At least one tag is required"),
});

type NewTopicFormValues = z.infer<typeof newTopicSchema>;

export default function ForumList({ topics, isLoading, onSelectTopic }: ForumListProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isNewTopicDialogOpen, setIsNewTopicDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<string>("popular");
  
  const form = useForm<NewTopicFormValues>({
    resolver: zodResolver(newTopicSchema),
    defaultValues: {
      title: "",
      content: "",
      tags: "",
    },
  });
  
  const createTopicMutation = useMutation({
    mutationFn: async (data: NewTopicFormValues) => {
      const res = await apiRequest("POST", "/api/forum/topics", {
        ...data,
        tags: data.tags.split(",").map(tag => tag.trim()),
      });
      return await res.json();
    },
    onSuccess: (newTopic) => {
      queryClient.invalidateQueries({ queryKey: ["/api/forum/topics"] });
      toast({
        title: "Success",
        description: "Your topic has been created successfully.",
      });
      setIsNewTopicDialogOpen(false);
      form.reset();
      // Navigate to the new topic
      onSelectTopic(newTopic);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create topic: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: NewTopicFormValues) => {
    createTopicMutation.mutate(data);
  };
  
  // Filter and sort topics based on active tab
  const getFilteredTopics = () => {
    if (!topics.length) return [];
    
    const sortedTopics = [...topics];
    
    switch (activeTab) {
      case "popular":
        return sortedTopics.sort((a, b) => (b.upvotes || 0) - (a.upvotes || 0));
      case "recent":
        return sortedTopics.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      case "your-topics":
        return sortedTopics.filter(topic => topic.authorId === user?.id);
      case "saved":
        return sortedTopics.filter(topic => topic.saved);
      default:
        return sortedTopics;
    }
  };
  
  const filteredTopics = getFilteredTopics();
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Discussion Forums</CardTitle>
            <CardDescription>Join conversations on topics that matter to you</CardDescription>
          </div>
          <Button onClick={() => setIsNewTopicDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Topic
          </Button>
        </CardHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 rounded-none border-b">
            <TabsTrigger value="popular">Popular</TabsTrigger>
            <TabsTrigger value="recent">Recent</TabsTrigger>
            <TabsTrigger value="your-topics">Your Topics</TabsTrigger>
            <TabsTrigger value="saved">Saved</TabsTrigger>
          </TabsList>
          
          <TabsContent value={activeTab} className="pt-0">
            {filteredTopics.length === 0 ? (
              <CardContent className="flex flex-col items-center justify-center py-10">
                <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No topics found</h3>
                <p className="text-muted-foreground text-center mt-2">
                  {activeTab === "your-topics" ? "You haven't created any topics yet." : 
                   activeTab === "saved" ? "You haven't saved any topics yet." : 
                   "Be the first to start a discussion!"}
                </p>
                {activeTab !== "your-topics" && activeTab !== "saved" && (
                  <Button onClick={() => setIsNewTopicDialogOpen(true)} className="mt-4">
                    Create New Topic
                  </Button>
                )}
              </CardContent>
            ) : (
              <CardContent className="p-0">
                <ul className="divide-y divide-neutral-200">
                  {filteredTopics.map((topic) => (
                    <li key={topic.id} className="hover:bg-neutral-50 transition-colors">
                      <button 
                        className="w-full text-left p-4 sm:p-6 focus:outline-none focus:bg-neutral-100"
                        onClick={() => onSelectTopic(topic)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <Avatar className="h-10 w-10 bg-primary">
                              <AvatarFallback>{topic.author.charAt(0).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className="ml-4">
                              <p className="text-sm font-medium text-primary">
                                {topic.title}
                              </p>
                              <p className="text-xs text-neutral-500">
                                Posted by {topic.author} • {new Date(topic.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center text-xs text-neutral-500">
                            <MessageSquare className="mr-1 h-4 w-4" />
                            <span className="mr-4">{topic.replies?.length || 0}</span>
                            <Heart className="mr-1 h-4 w-4" />
                            <span>{topic.upvotes || 0}</span>
                          </div>
                        </div>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {topic.tags?.map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs capitalize">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              </CardContent>
            )}
          </TabsContent>
        </Tabs>
        
        <CardFooter className="bg-neutral-50 flex justify-between py-3">
          <div className="text-xs text-neutral-500">
            {filteredTopics.length} topic{filteredTopics.length !== 1 ? 's' : ''}
          </div>
          {topics.length > 10 && (
            <Button variant="link" size="sm" className="text-primary">
              View all discussions
            </Button>
          )}
        </CardFooter>
      </Card>
      
      <Dialog open={isNewTopicDialogOpen} onOpenChange={setIsNewTopicDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Create New Topic</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="What's your question or discussion topic?" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Provide details about your topic..."
                        className="min-h-[150px]"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="tags"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tags</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Separate tags with commas (e.g. organic, rice, pesticides)"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button 
                  variant="outline" 
                  type="button"
                  onClick={() => setIsNewTopicDialogOpen(false)}
                  disabled={createTopicMutation.isPending}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createTopicMutation.isPending}
                >
                  {createTopicMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Create Topic
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
}
