import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ForumTopic, ForumGroup, ForumReply } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Send, Loader2, ThumbsUp, Heart } from "lucide-react";

interface ChatProps {
  topic?: ForumTopic;
  group?: ForumGroup;
  onBack: () => void;
}

const replySchema = z.object({
  content: z.string().min(1, "Reply cannot be empty").max(1000, "Reply is too long"),
});

type ReplyFormValues = z.infer<typeof replySchema>;

export default function Chat({ topic, group, onBack }: ChatProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatEntity = topic || group;
  
  const isGroup = !!group;
  const chatId = chatEntity?.id;
  
  const form = useForm<ReplyFormValues>({
    resolver: zodResolver(replySchema),
    defaultValues: {
      content: "",
    },
  });
  
  // Get replies/messages for the topic or group
  const { data: replies = [], isLoading, refetch: refetchReplies } = useQuery<ForumReply[]>({
    queryKey: [isGroup ? `/api/forum/groups/${chatId}/messages` : `/api/forum/topics/${chatId}/replies`],
    enabled: !!chatId,
  });
  
  // Send a reply/message
  const sendReplyMutation = useMutation({
    mutationFn: async (data: ReplyFormValues) => {
      const endpoint = isGroup 
        ? `/api/forum/groups/${chatId}/messages` 
        : `/api/forum/topics/${chatId}/replies`;
        
      const res = await apiRequest("POST", endpoint, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [isGroup ? `/api/forum/groups/${chatId}/messages` : `/api/forum/topics/${chatId}/replies`] 
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to send message: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Upvote/like a reply
  const upvoteReplyMutation = useMutation({
    mutationFn: async (replyId: number) => {
      const endpoint = isGroup 
        ? `/api/forum/groups/${chatId}/messages/${replyId}/upvote` 
        : `/api/forum/topics/${chatId}/replies/${replyId}/upvote`;
        
      const res = await apiRequest("POST", endpoint);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [isGroup ? `/api/forum/groups/${chatId}/messages` : `/api/forum/topics/${chatId}/replies`] 
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to upvote: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Setup WebSocket connection for real-time messages
  useEffect(() => {
    if (!chatId) return;
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws/${isGroup ? 'group' : 'topic'}/${chatId}`;
    
    const socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      console.log('Connected to WebSocket');
    };
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      // Update messages/replies when receiving new ones
      if (data.type === 'new_message' || data.type === 'new_reply') {
        refetchReplies();
      }
    };
    
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    return () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [chatId, isGroup, refetchReplies]);
  
  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [replies]);
  
  const onSubmit = (data: ReplyFormValues) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "You must be logged in to send messages.",
        variant: "destructive",
      });
      return;
    }
    
    sendReplyMutation.mutate(data);
  };
  
  if (!chatEntity) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <h3 className="text-lg font-medium">No topic or group selected</h3>
          <Button onClick={onBack} className="mt-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Go Back
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="flex flex-col h-[70vh]">
      <CardHeader className="flex flex-row items-center space-y-0 py-4">
        <Button variant="ghost" size="sm" onClick={onBack} className="mr-2">
          <ArrowLeft className="h-4 w-4" />
          <span className="sr-only">Back</span>
        </Button>
        <div className="flex-1 overflow-hidden">
          <CardTitle className="text-base sm:text-lg truncate">
            {chatEntity.name || chatEntity.title}
          </CardTitle>
          <CardDescription className="text-xs truncate">
            {isGroup 
              ? `${chatEntity.memberCount} members • ${chatEntity.activityLevel}`
              : `Posted by ${(topic as ForumTopic)?.author} • ${new Date((topic as ForumTopic)?.createdAt).toLocaleDateString()}`
            }
          </CardDescription>
        </div>
      </CardHeader>
      
      {!isGroup && topic && (
        <div className="px-4 py-2 border-t border-b border-neutral-200 bg-neutral-50">
          <h3 className="font-medium text-sm">{topic.title}</h3>
          <p className="text-sm text-neutral-600 mt-1 line-clamp-2">{topic.content}</p>
          {topic.tags && (
            <div className="flex flex-wrap gap-1 mt-2">
              {topic.tags.map((tag, index) => (
                <Badge key={index} variant="outline" className="text-xs capitalize">
                  {tag}
                </Badge>
              ))}
            </div>
          )}
        </div>
      )}
      
      <CardContent className="flex-1 overflow-y-auto p-4">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : replies.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <p className="text-neutral-500">
              {isGroup 
                ? "No messages in this group yet. Be the first to send a message!" 
                : "No replies to this topic yet. Be the first to reply!"
              }
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {replies.map((reply) => (
              <div 
                key={reply.id} 
                className={`flex gap-3 ${reply.authorId === user?.id ? 'justify-end' : ''}`}
              >
                {reply.authorId !== user?.id && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{reply.author.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                )}
                <div className={`max-w-[80%] ${reply.authorId === user?.id ? 'bg-primary text-white' : 'bg-neutral-100'} rounded-lg p-3`}>
                  {reply.authorId !== user?.id && (
                    <div className="font-medium text-xs mb-1">
                      {reply.author}
                    </div>
                  )}
                  <p className="text-sm break-words">{reply.content}</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs opacity-70">
                      {new Date(reply.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {!isGroup && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className={`h-6 px-1 ${reply.authorId === user?.id ? 'text-white' : 'text-neutral-500'}`}
                        onClick={() => upvoteReplyMutation.mutate(reply.id)}
                      >
                        {reply.upvoted ? (
                          <Heart className="h-3 w-3 fill-current" />
                        ) : (
                          <Heart className="h-3 w-3" />
                        )}
                        <span className="ml-1 text-xs">{reply.upvotes || 0}</span>
                      </Button>
                    )}
                  </div>
                </div>
                {reply.authorId === user?.id && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{reply.author.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </CardContent>
      
      <CardFooter className="border-t p-4">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="w-full flex gap-2">
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <Textarea 
                      placeholder={isGroup ? "Type a message..." : "Write a reply..."}
                      className="min-h-[60px] resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button 
              type="submit" 
              size="icon"
              disabled={sendReplyMutation.isPending}
              className="h-[60px] w-[60px]"
            >
              {sendReplyMutation.isPending ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </Button>
          </form>
        </Form>
      </CardFooter>
    </Card>
  );
}
