import { ForumGroup } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, UserCheck } from "lucide-react";

interface GroupListProps {
  groups: ForumGroup[];
  isLoading: boolean;
  onSelectGroup: (group: ForumGroup) => void;
}

export default function GroupList({ groups, isLoading, onSelectGroup }: GroupListProps) {
  const { toast } = useToast();
  
  const joinGroupMutation = useMutation({
    mutationFn: async (groupId: number) => {
      const res = await apiRequest("POST", `/api/forum/groups/${groupId}/join`);
      return await res.json();
    },
    onSuccess: (updatedGroup) => {
      queryClient.invalidateQueries({ queryKey: ["/api/forum/groups"] });
      toast({
        title: "Group joined",
        description: `You have successfully joined the ${updatedGroup.name} group.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to join group: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const getGroupIcon = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'organic farming':
        return "seedling";
      case 'modern techniques':
        return "tractor";
      case 'weather & climate':
        return "cloud-sun-rain";
      default:
        return "users";
    }
  };
  
  const getGroupIconColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'organic farming':
        return "bg-green-100";
      case 'modern techniques':
        return "bg-blue-100";
      case 'weather & climate':
        return "bg-yellow-100";
      default:
        return "bg-green-100";
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (groups.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <UserCheck className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">No community groups available</h3>
          <p className="text-muted-foreground text-center mt-2">
            Check back soon for new groups to join!
          </p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {groups.map((group) => (
        <Card key={group.id} className="overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className={`flex-shrink-0 ${getGroupIconColor(group.category)} rounded-md p-3`}>
                <i className={`fas fa-${getGroupIcon(group.category)} text-primary-dark text-xl`}></i>
              </div>
              <div className="ml-5">
                <h3 className="text-lg leading-6 font-medium text-neutral-900">
                  {group.name}
                </h3>
                <p className="text-sm text-neutral-500">
                  {group.memberCount} members • {group.activityLevel}
                </p>
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm text-neutral-600">
                {group.description}
              </p>
            </div>
            <div className="mt-5 flex space-x-2">
              {group.isMember ? (
                <Button
                  variant="default"
                  onClick={() => onSelectGroup(group)}
                >
                  Open Group Chat
                </Button>
              ) : (
                <Button
                  variant="default"
                  onClick={() => joinGroupMutation.mutate(group.id)}
                  disabled={joinGroupMutation.isPending && joinGroupMutation.variables === group.id}
                >
                  {joinGroupMutation.isPending && joinGroupMutation.variables === group.id ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Joining...
                    </>
                  ) : (
                    "Join Group"
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
