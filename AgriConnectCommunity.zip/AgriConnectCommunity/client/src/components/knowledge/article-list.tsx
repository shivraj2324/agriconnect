import { useState } from "react";
import { Article } from "@shared/schema";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Loader2, BookOpen, Calendar, Tag, User, ExternalLink } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface ArticleListProps {
  articles: Article[];
  isLoading: boolean;
  searchQuery: string;
}

export default function ArticleList({ articles, isLoading, searchQuery }: ArticleListProps) {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  
  const handleReadArticle = (article: Article) => {
    setSelectedArticle(article);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };
  
  const highlightText = (text: string, query: string) => {
    if (!query.trim()) {
      return text;
    }

    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    
    return parts.map((part, index) => 
      part.toLowerCase() === query.toLowerCase() 
        ? <span key={index} className="bg-yellow-200">{part}</span> 
        : part
    );
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (articles.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">No articles found</h3>
          <p className="text-muted-foreground text-center mt-2">
            {searchQuery ? "Try changing your search query or category filter." : "Check back soon for new content!"}
          </p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((article) => (
          <Card key={article.id} className="overflow-hidden flex flex-col">
            {article.imageUrl && (
              <div className="aspect-video relative overflow-hidden">
                <img 
                  src={article.imageUrl} 
                  alt={article.title} 
                  className="w-full h-full object-cover transition-transform hover:scale-105"
                />
              </div>
            )}
            
            <CardHeader className="flex-grow">
              <div className="flex items-center space-x-2 mb-2">
                <Badge variant="outline" className="capitalize">
                  {article.category}
                </Badge>
                {article.source === "internal" ? (
                  <Badge variant="default" className="bg-primary/80">
                    Official
                  </Badge>
                ) : (
                  <Badge variant="secondary">
                    External
                  </Badge>
                )}
              </div>
              
              <CardTitle className="line-clamp-2">
                {highlightText(article.title, searchQuery)}
              </CardTitle>
              
              <CardDescription className="line-clamp-3 mt-2">
                {highlightText(article.summary || article.content.substring(0, 150) + "...", searchQuery)}
              </CardDescription>
            </CardHeader>
            
            <CardFooter className="pt-0 pb-4 flex flex-col items-start">
              <div className="flex items-center text-sm text-muted-foreground mb-3">
                <Calendar className="h-4 w-4 mr-2" />
                <span>{formatDate(article.publishedAt)}</span>
              </div>
              
              <Button 
                variant={article.source === "internal" ? "default" : "outline"}
                className="w-full"
                onClick={() => handleReadArticle(article)}
              >
                Read Article
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      {/* Article dialog */}
      <Dialog open={!!selectedArticle} onOpenChange={(open) => !open && setSelectedArticle(null)}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedArticle && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedArticle.title}</DialogTitle>
              </DialogHeader>
              
              {selectedArticle.imageUrl && (
                <div className="aspect-video overflow-hidden rounded-md my-4">
                  <img 
                    src={selectedArticle.imageUrl} 
                    alt={selectedArticle.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              
              <div className="flex flex-wrap items-center gap-4 mb-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>{formatDate(selectedArticle.publishedAt)}</span>
                </div>
                
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  <span>By {selectedArticle.author}</span>
                </div>
                
                <div className="flex items-center">
                  <Tag className="h-4 w-4 mr-2" />
                  <span className="capitalize">{selectedArticle.category}</span>
                </div>
              </div>
              
              <Separator className="my-2" />
              
              <div className="prose max-w-none mt-4">
                {selectedArticle.content.split('\n').map((paragraph, i) => (
                  <p key={i} className="my-4">{paragraph}</p>
                ))}
              </div>
              
              {selectedArticle.tags && selectedArticle.tags.length > 0 && (
                <div className="mt-6">
                  <h4 className="text-sm font-medium mb-2">Related Topics</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedArticle.tags.map((tag, i) => (
                      <Badge key={i} variant="outline" className="capitalize">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedArticle.source === "external" && selectedArticle.sourceUrl && (
                <div className="mt-6">
                  <Button variant="outline" asChild>
                    <a 
                      href={selectedArticle.sourceUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Original Source
                    </a>
                  </Button>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
