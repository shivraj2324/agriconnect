import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Bell, Menu, X, Leaf, User } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Use try-catch to prevent errors if AuthContext is not available
  let user = null;
  let logoutMutation = { mutate: () => {}, isPending: false };
  try {
    const auth = useAuth();
    user = auth.user;
    logoutMutation = auth.logoutMutation;
  } catch (error) {
    console.log("Auth context not available on initial render");
  }
  
  const navigation = [
    { name: "Home", href: "/" },
    { name: "Crop Planner", href: "/crop-planner" },
    { name: "Knowledge Hub", href: "/knowledge-hub" },
    { name: "Marketplace", href: "/dashboard" },
    { name: "Community", href: "/community" },
  ];
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const getInitials = (name: string) => {
    return name ? name.charAt(0).toUpperCase() : "U";
  };
  
  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <Button variant="link" className="flex items-center cursor-pointer p-0">
                  <Leaf className="h-6 w-6 text-primary mr-2" />
                  <span className="font-bold text-primary text-xl">AgriConnect</span>
                </Button>
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              {navigation.map((item) => (
                <Link key={item.name} href={item.href}>
                  <Button 
                    variant="link" 
                    className={`${
                      location === item.href
                        ? "border-primary text-primary"
                        : "border-transparent text-neutral-500 hover:border-neutral-300 hover:text-neutral-700"
                    } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-full`}
                  >
                    {item.name}
                  </Button>
                </Link>
              ))}
            </div>
          </div>
          
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            <Button variant="ghost" size="icon" aria-label="Notifications">
              <Bell className="h-5 w-5 text-neutral-400" />
            </Button>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full ml-3">
                    <Avatar className="h-8 w-8 bg-primary text-primary-foreground">
                      <AvatarFallback>
                        {getInitials(user.firstName || user.username)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <div className="flex items-center justify-start gap-2 p-2">
                    <div className="flex flex-col space-y-1 leading-none">
                      <p className="font-medium">{user.firstName} {user.lastName}</p>
                      <p className="w-[200px] truncate text-sm text-muted-foreground">
                        {user.email || user.username}
                      </p>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard">
                      <Button variant="ghost" className="cursor-pointer w-full justify-start">Dashboard</Button>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <Button variant="ghost" className="cursor-pointer w-full justify-start">Profile</Button>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/settings">
                      <Button variant="ghost" className="cursor-pointer w-full justify-start">Settings</Button>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={handleLogout}
                    disabled={logoutMutation.isPending}
                  >
                    {logoutMutation.isPending ? "Signing out..." : "Sign out"}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <Button className="ml-4">Sign In</Button>
              </Link>
            )}
          </div>
          
          <div className="sm:hidden flex items-center">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-neutral-500">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="sm:max-w-xs">
                <div className="flex items-center mb-6">
                  <Leaf className="h-6 w-6 text-primary mr-2" />
                  <span className="font-bold text-primary text-xl">AgriConnect</span>
                </div>
                <nav className="flex flex-col space-y-1">
                  {navigation.map((item) => (
                    <Link 
                      key={item.name} 
                      href={item.href} 
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Button 
                        variant="ghost"
                        className={`${
                          location === item.href
                            ? "bg-primary-light/20 text-primary border-l-4 border-primary"
                            : "text-neutral-500 hover:bg-neutral-50 hover:text-neutral-900"
                        } group flex items-center px-3 py-2 text-base font-medium rounded-md w-full justify-start`}
                      >
                        {item.name}
                      </Button>
                    </Link>
                  ))}
                  
                  {user ? (
                    <>
                      <div className="border-t border-neutral-200 pt-4 mt-4">
                        <div className="flex items-center px-3 py-3">
                          <div className="flex-shrink-0">
                            <Avatar className="h-10 w-10 bg-primary text-primary-foreground">
                              <AvatarFallback>
                                {getInitials(user.firstName || user.username)}
                              </AvatarFallback>
                            </Avatar>
                          </div>
                          <div className="ml-3">
                            <div className="text-base font-medium text-neutral-800">
                              {user.firstName} {user.lastName}
                            </div>
                            <div className="text-sm font-medium text-neutral-500">
                              {user.email || user.username}
                            </div>
                          </div>
                          <Button variant="ghost" size="icon" className="ml-auto" aria-label="Notifications">
                            <Bell className="h-5 w-5 text-neutral-400" />
                          </Button>
                        </div>
                        
                        <div className="mt-3 space-y-1">
                          <Link 
                            href="/profile" 
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            <Button variant="ghost" className="w-full justify-start px-3 py-2 text-base font-medium">
                              Your Profile
                            </Button>
                          </Link>
                          <Link 
                            href="/settings" 
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            <Button variant="ghost" className="w-full justify-start px-3 py-2 text-base font-medium">
                              Settings
                            </Button>
                          </Link>
                          <Button 
                            variant="ghost" 
                            className="w-full justify-start px-3 py-2 text-base font-medium text-neutral-500 hover:bg-neutral-50 hover:text-neutral-900"
                            onClick={() => {
                              handleLogout();
                              setMobileMenuOpen(false);
                            }}
                            disabled={logoutMutation.isPending}
                          >
                            {logoutMutation.isPending ? "Signing out..." : "Sign out"}
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="border-t border-neutral-200 pt-4 mt-4">
                      <Link 
                        href="/auth" 
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        <Button className="w-full">Sign In</Button>
                      </Link>
                    </div>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
