import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import WeatherWidget from "@/components/crop-planner/weather-widget";
import { Leaf, Book, Store, Users, ArrowRight } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

const features = [
  {
    icon: <Leaf className="h-6 w-6" />,
    title: "Smart Crop Planner",
    description: "Get recommendations for crops based on your soil type, local climate, and historical yields. Includes real-time weather integration."
  },
  {
    icon: <Book className="h-6 w-6" />,
    title: "Knowledge Hub",
    description: "Access tutorials, articles, and region-specific farming tips. Learn about pest control, irrigation techniques, and more."
  },
  {
    icon: <Store className="h-6 w-6" />,
    title: "Farm Marketplace",
    description: "Sell your products directly to consumers and connect with buyers. Manage inventory and track sales through your dashboard."
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: "Community Forum",
    description: "Connect with other farmers, share experiences, ask questions, and offer advice in a supportive WhatsApp-like community."
  }
];

export default function HomePage() {
  // Use try-catch to prevent errors if AuthContext is not available
  let user = null;
  try {
    const auth = useAuth();
    user = auth.user;
  } catch (error) {
    console.log("Auth context not available on initial render");
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="relative z-10 pb-8 sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
            <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
              <div className="sm:text-center lg:text-left">
                <h1 className="text-4xl tracking-tight font-bold text-neutral-900 sm:text-5xl md:text-6xl font-heading">
                  <span className="block xl:inline">Smart farming for</span>
                  <span className="block text-primary xl:inline"> better harvests</span>
                </h1>
                <p className="mt-3 text-base text-neutral-600 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                  Connect with fellow farmers, plan your crops intelligently, and access a marketplace to grow your agricultural business.
                </p>
                <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                  {user ? (
                    <Link href="/dashboard">
                      <Button size="lg" className="px-8 py-3 text-base sm:text-lg">
                        Go to Dashboard
                      </Button>
                    </Link>
                  ) : (
                    <Link href="/auth">
                      <Button size="lg" className="px-8 py-3 text-base sm:text-lg">
                        Get started
                      </Button>
                    </Link>
                  )}
                  <Link href="/knowledge-hub">
                    <Button variant="outline" size="lg" className="mt-3 sm:mt-0 sm:ml-3 px-8 py-3 text-base sm:text-lg">
                      Learn more
                    </Button>
                  </Link>
                </div>
              </div>
            </main>
          </div>
        </div>
        <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
          <img 
            className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full" 
            src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1932&q=80" 
            alt="Farmer in field" 
          />
        </div>
      </div>
      
      {/* Weather Widget */}
      <div className="bg-primary-light/20 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <WeatherWidget />
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Features</h2>
            <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-neutral-900 sm:text-4xl">
              Everything you need for smarter farming
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 lg:mx-auto">
              AgriConnect brings together the tools and community you need to succeed in modern agriculture.
            </p>
          </div>

          <div className="mt-10">
            <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
              {features.map((feature, index) => (
                <div key={index} className="relative">
                  <dt>
                    <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                      {feature.icon}
                    </div>
                    <p className="ml-16 text-lg leading-6 font-medium text-neutral-900">{feature.title}</p>
                  </dt>
                  <dd className="mt-2 ml-16 text-base text-neutral-500">
                    {feature.description}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
          
          <div className="mt-10 text-center">
            {user ? (
              <Link href="/dashboard">
                <Button variant="default" className="mt-6">
                  Access all features <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            ) : (
              <Link href="/auth">
                <Button variant="default" className="mt-6">
                  Join now <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
