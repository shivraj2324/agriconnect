import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import ProductList from "@/components/dashboard/product-list";
import ProductForm from "@/components/dashboard/product-form";
import SalesAnalytics from "@/components/dashboard/sales-analytics";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Product } from "@shared/schema";

export default function DashboardPage() {
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [activeTab, setActiveTab] = useState<string>("products");
  
  const { data: products = [], isLoading: isLoadingProducts, refetch: refetchProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });
  
  const handleAddProduct = () => {
    setEditingProduct(null);
    setIsProductFormOpen(true);
  };
  
  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setIsProductFormOpen(true);
  };
  
  const handleProductFormClose = () => {
    setIsProductFormOpen(false);
    setEditingProduct(null);
    refetchProducts();
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="py-10 bg-neutral-50 flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-neutral-900">Farm Marketplace</h1>
            <p className="mt-2 text-lg text-neutral-500">
              Sell your products and connect with buyers
            </p>
          </div>
          
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="mb-8"
          >
            <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
              <TabsTrigger value="products">Your Products</TabsTrigger>
              <TabsTrigger value="analytics">Sales Analytics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="products" className="pt-6">
              <div className="flex justify-end mb-4">
                <Button onClick={handleAddProduct}>
                  Add New Product
                </Button>
              </div>
              
              <ProductList 
                products={products} 
                isLoading={isLoadingProducts}
                onEdit={handleEditProduct} 
                onRefresh={refetchProducts}
              />
            </TabsContent>
            
            <TabsContent value="analytics" className="pt-6">
              <SalesAnalytics products={products} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      <Dialog open={isProductFormOpen} onOpenChange={setIsProductFormOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogTitle>
            {editingProduct ? "Edit Product" : "Add New Product"}
          </DialogTitle>
          <ProductForm 
            product={editingProduct} 
            onClose={handleProductFormClose} 
          />
        </DialogContent>
      </Dialog>
      
      <Footer />
    </div>
  );
}
