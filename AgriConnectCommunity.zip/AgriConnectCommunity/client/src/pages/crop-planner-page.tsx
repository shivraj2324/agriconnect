import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import RecommendationForm from "@/components/crop-planner/recommendation-form";
import WeatherWidget from "@/components/crop-planner/weather-widget";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { CropRecommendation } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { 
  Loader2, 
  Calendar, 
  Sprout, 
  CloudRain, 
  Droplets, 
  ThermometerSun, 
  Wind, 
  Timer, 
  AlertTriangle, 
  CheckCircle2,
  BarChart3
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function CropPlannerPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("recommendations");
  const [weatherData, setWeatherData] = useState<any>(null);
  const [selectedWeatherParam, setSelectedWeatherParam] = useState<string>("all");
  
  const { data: recommendations = [], isLoading: isLoadingRecommendations } = useQuery<CropRecommendation[]>({
    queryKey: ["/api/crop-recommendations"],
  });

  const { data: userCrops = [], isLoading: isLoadingUserCrops } = useQuery<CropRecommendation[]>({
    queryKey: ["/api/user-crops"],
  });

  // Define interface for weather data
  interface WeatherData {
    location: string;
    temperature: number;
    condition: string;
    humidity: number;
    windSpeed: number;
    forecast: string;
  }

  // Fetch weather data
  const { data: weather, isLoading: isLoadingWeather } = useQuery<WeatherData>({
    queryKey: ["/api/weather"]
  });

  // Update weather data when it changes
  useEffect(() => {
    if (weather) {
      setWeatherData(weather);
    }
  }, [weather]);

  // Get current season based on month
  const getCurrentSeason = () => {
    const month = new Date().getMonth();
    if (month >= 2 && month <= 4) return "Spring";
    if (month >= 5 && month <= 7) return "Summer";
    if (month >= 8 && month <= 10) return "Fall";
    return "Winter";
  };
  
  const currentSeason = getCurrentSeason();
  const region = user?.region || "Central India";

  // Calculate irrigation recommendation based on weather conditions
  const getIrrigationRecommendation = () => {
    if (!weatherData) return "Unable to provide recommendations without weather data.";
    
    const { condition, temperature, humidity } = weatherData;
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes("rain") || conditionLower.includes("drizzle")) {
      return "Delay irrigation due to current rainfall. Check for water logging in low-lying areas.";
    } else if (temperature > 35) {
      if (humidity < 40) {
        return "Critical: Increase irrigation frequency due to high temperature and low humidity. Consider drip irrigation to conserve water.";
      } else {
        return "Moderate irrigation needed despite high temperature due to better humidity levels.";
      }
    } else if (temperature > 25) {
      if (humidity < 30) {
        return "Regular irrigation recommended. Morning or evening watering is optimal to reduce evaporation loss.";
      } else {
        return "Light irrigation sufficient. Monitor soil moisture levels before watering.";
      }
    } else {
      return "Minimal irrigation required. Focus on young plants and recently sown fields.";
    }
  };

  // Calculate soil moisture management recommendation
  const getSoilMoistureRecommendation = () => {
    if (!weatherData) return "Unable to provide recommendations without weather data.";
    
    const { condition, temperature, humidity } = weatherData;
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes("rain")) {
      return "Ensure proper drainage to prevent waterlogging. Check for standing water in fields.";
    } else if (temperature > 30 && humidity < 40) {
      return "Apply mulch to retain soil moisture. Consider organic mulches like straw or dry leaves.";
    } else {
      return "Maintain current soil moisture management practices. Monitor regularly.";
    }
  };

  // Calculate pest and disease risk
  const getPestDiseaseRisk = () => {
    if (!weatherData) return { risk: "Unknown", description: "Unable to assess risk without weather data." };
    
    const { condition, temperature, humidity } = weatherData;
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes("rain") && temperature > 25 && humidity > 70) {
      return {
        risk: "High",
        description: "Warm, humid conditions with rain create favorable environment for fungal diseases and pests. Monitor crops daily and consider preventive spraying."
      };
    } else if (temperature > 30 && humidity > 60) {
      return {
        risk: "Moderate",
        description: "Warm and humid conditions may promote certain pests. Regular monitoring recommended."
      };
    } else if (temperature < 15) {
      return {
        risk: "Low",
        description: "Cool temperatures typically reduce pest activity. Continue routine monitoring."
      };
    } else {
      return {
        risk: "Low to Moderate",
        description: "Current conditions not particularly favorable for major pest outbreaks. Maintain regular monitoring schedule."
      };
    }
  };

  // Generate harvest timing recommendation
  const getHarvestRecommendation = () => {
    if (!weatherData) return "Unable to provide harvest recommendations without weather data.";
    
    const { condition, temperature } = weatherData;
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes("rain") || conditionLower.includes("thunder")) {
      return "Delay harvesting until dry conditions return. Harvesting during rainfall can reduce crop quality and increase post-harvest losses.";
    } else if (conditionLower.includes("clear") || conditionLower.includes("sun")) {
      if (temperature > 35) {
        return "Early morning or late evening harvesting recommended to avoid heat stress on workers and crops.";
      } else {
        return "Excellent harvesting conditions. For optimal quality, harvest during mid-morning after dew has evaporated.";
      }
    } else {
      return "Standard harvesting practices can be followed. Monitor forecast for upcoming changes in weather.";
    }
  };

  const pestRisk = getPestDiseaseRisk();

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="py-10 bg-neutral-50 flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-neutral-900">Smart Crop Planner</h1>
            <p className="mt-2 text-lg text-neutral-500">
              Get personalized crop recommendations and real-time farming insights
            </p>
          </div>
          
          <div className="mb-8">
            <WeatherWidget />
          </div>

          {/* Farming Parameters Dashboard */}
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  Farming Parameters Dashboard
                </CardTitle>
                <CardDescription>
                  Real-time recommendations based on current weather conditions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <Card className="bg-primary/5">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <h3 className="text-sm font-medium">Temperature</h3>
                          <p className="text-2xl font-bold">{weatherData?.temperature || "N/A"}°C</p>
                        </div>
                        <ThermometerSun className="h-10 w-10 text-primary/70" />
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {weatherData?.temperature > 30 
                          ? "High temperature affects water requirements" 
                          : weatherData?.temperature < 15 
                            ? "Low temperature may slow crop growth" 
                            : "Optimal temperature for most crops"}
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-blue-50">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <h3 className="text-sm font-medium">Humidity</h3>
                          <p className="text-2xl font-bold">{weatherData?.humidity || "N/A"}%</p>
                        </div>
                        <Droplets className="h-10 w-10 text-blue-500/70" />
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {weatherData?.humidity > 70 
                          ? "High humidity increases disease risk" 
                          : weatherData?.humidity < 30 
                            ? "Low humidity increases water loss" 
                            : "Moderate humidity is generally favorable"}
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-amber-50">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <h3 className="text-sm font-medium">Wind Speed</h3>
                          <p className="text-2xl font-bold">{weatherData?.windSpeed || "N/A"} km/h</p>
                        </div>
                        <Wind className="h-10 w-10 text-amber-500/70" />
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {weatherData?.windSpeed > 20 
                          ? "Strong winds may damage crops" 
                          : weatherData?.windSpeed < 5 
                            ? "Low wind reduces pollination" 
                            : "Moderate wind helps with pollination"}
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-green-50">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <h3 className="text-sm font-medium">Pest Risk</h3>
                          <p className="text-2xl font-bold">{pestRisk.risk}</p>
                        </div>
                        {pestRisk.risk === "High" 
                          ? <AlertTriangle className="h-10 w-10 text-red-500/70" />
                          : pestRisk.risk === "Moderate"
                            ? <AlertTriangle className="h-10 w-10 text-amber-500/70" />
                            : <CheckCircle2 className="h-10 w-10 text-green-500/70" />
                        }
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {pestRisk.description.slice(0, 60)}...
                      </p>
                    </CardContent>
                  </Card>
                </div>

                <Select
                  value={selectedWeatherParam}
                  onValueChange={setSelectedWeatherParam}
                >
                  <SelectTrigger className="w-full md:w-[300px] mb-4">
                    <SelectValue placeholder="Select recommendation type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Recommendations</SelectItem>
                    <SelectItem value="irrigation">Irrigation Management</SelectItem>
                    <SelectItem value="soil">Soil Moisture Management</SelectItem>
                    <SelectItem value="pests">Pest & Disease Management</SelectItem>
                    <SelectItem value="harvest">Harvest Timing</SelectItem>
                  </SelectContent>
                </Select>

                <Accordion 
                  type="single" 
                  collapsible
                  defaultValue={selectedWeatherParam === "all" ? "irrigation" : selectedWeatherParam}
                >
                  {(selectedWeatherParam === "all" || selectedWeatherParam === "irrigation") && (
                    <AccordionItem value="irrigation">
                      <AccordionTrigger className="text-base font-medium hover:no-underline">
                        <div className="flex items-center gap-2">
                          <Droplets className="h-5 w-5 text-blue-600" />
                          Irrigation Management
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="p-2 rounded-md bg-blue-50 mb-2">
                          <p>{getIrrigationRecommendation()}</p>
                        </div>
                        <div className="mt-4">
                          <h4 className="text-sm font-medium mb-2">Water requirement scale:</h4>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">Low</span>
                            <Progress 
                              value={weatherData?.temperature > 35 ? 90 : weatherData?.temperature > 30 ? 70 : weatherData?.temperature > 25 ? 50 : 30} 
                              className="h-2 flex-1" 
                            />
                            <span className="text-xs text-muted-foreground">High</span>
                          </div>
                        </div>
                        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Recommended irrigation time:</h4>
                            <p className="text-sm">{weatherData?.temperature > 30 ? "Early morning or late evening" : "Morning"}</p>
                          </div>
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Irrigation method:</h4>
                            <p className="text-sm">{weatherData?.temperature > 35 ? "Drip irrigation recommended" : "Standard methods acceptable"}</p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}

                  {(selectedWeatherParam === "all" || selectedWeatherParam === "soil") && (
                    <AccordionItem value="soil">
                      <AccordionTrigger className="text-base font-medium hover:no-underline">
                        <div className="flex items-center gap-2">
                          <Sprout className="h-5 w-5 text-green-600" />
                          Soil Moisture Management
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="p-2 rounded-md bg-green-50 mb-2">
                          <p>{getSoilMoistureRecommendation()}</p>
                        </div>
                        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Mulching recommendation:</h4>
                            <p className="text-sm">
                              {weatherData?.temperature > 30 && weatherData?.humidity < 50 
                                ? "Apply organic mulch to retain moisture" 
                                : "Standard mulching practices recommended"}
                            </p>
                          </div>
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Soil amendment recommendation:</h4>
                            <p className="text-sm">
                              {weatherData?.condition?.toLowerCase().includes("rain") 
                                ? "Consider adding organic matter to improve soil drainage"
                                : "Standard soil amendment practices recommended"}
                            </p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}

                  {(selectedWeatherParam === "all" || selectedWeatherParam === "pests") && (
                    <AccordionItem value="pests">
                      <AccordionTrigger className="text-base font-medium hover:no-underline">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="h-5 w-5 text-amber-600" />
                          Pest & Disease Management
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="p-2 rounded-md bg-amber-50 mb-2">
                          <p>{pestRisk.description}</p>
                        </div>
                        <div className="mt-4">
                          <h4 className="text-sm font-medium mb-2">Risk level:</h4>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">Low</span>
                            <Progress 
                              value={pestRisk.risk === "High" ? 90 : pestRisk.risk === "Moderate" ? 50 : 20} 
                              className={`h-2 flex-1 ${pestRisk.risk === "High" ? "text-red-500" : pestRisk.risk === "Moderate" ? "text-amber-500" : "text-green-500"}`}
                            />
                            <span className="text-xs text-muted-foreground">High</span>
                          </div>
                        </div>
                        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Monitoring recommendation:</h4>
                            <p className="text-sm">
                              {pestRisk.risk === "High" 
                                ? "Daily monitoring of crops recommended" 
                                : pestRisk.risk === "Moderate"
                                  ? "Monitor crops every 2-3 days"
                                  : "Standard weekly monitoring sufficient"}
                            </p>
                          </div>
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Treatment recommendation:</h4>
                            <p className="text-sm">
                              {pestRisk.risk === "High" 
                                ? "Consider preventive biological or chemical controls" 
                                : pestRisk.risk === "Moderate"
                                  ? "Have treatments ready but apply only if pests observed"
                                  : "No immediate treatment necessary"}
                            </p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}

                  {(selectedWeatherParam === "all" || selectedWeatherParam === "harvest") && (
                    <AccordionItem value="harvest">
                      <AccordionTrigger className="text-base font-medium hover:no-underline">
                        <div className="flex items-center gap-2">
                          <Timer className="h-5 w-5 text-purple-600" />
                          Harvest Timing
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="p-2 rounded-md bg-purple-50 mb-2">
                          <p>{getHarvestRecommendation()}</p>
                        </div>
                        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Optimal harvest time:</h4>
                            <p className="text-sm">
                              {weatherData?.temperature > 35 
                                ? "Early morning (5-8 AM) or late evening (after 5 PM)" 
                                : weatherData?.condition?.toLowerCase().includes("clear")
                                  ? "Mid-morning (9 AM - 11 AM)"
                                  : "Standard harvest times acceptable"}
                            </p>
                          </div>
                          <div className="p-3 border rounded-md">
                            <h4 className="text-sm font-medium mb-1">Post-harvest handling:</h4>
                            <p className="text-sm">
                              {weatherData?.temperature > 30 
                                ? "Move harvested crops to shade immediately" 
                                : "Standard post-harvest practices acceptable"}
                            </p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}
                </Accordion>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Planting Calendar</CardTitle>
                  <CardDescription>Current recommended planting schedule</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Calendar className="h-5 w-5 text-primary mr-2" />
                        <span className="font-medium">Current Season</span>
                      </div>
                      <Badge>{currentSeason}</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Sprout className="h-5 w-5 text-primary mr-2" />
                        <span className="font-medium">Growing Region</span>
                      </div>
                      <Badge variant="outline" className="capitalize">{region}</Badge>
                    </div>
                    
                    <div className="border rounded-md p-3 mt-4">
                      <h4 className="font-medium mb-2 text-sm">Ideal for planting this season:</h4>
                      <div className="flex flex-wrap gap-1">
                        {currentSeason === "Summer" && (
                          <>
                            <Badge variant="outline">Cotton</Badge>
                            <Badge variant="outline">Rice</Badge>
                            <Badge variant="outline">Soybeans</Badge>
                            <Badge variant="outline">Maize</Badge>
                          </>
                        )}
                        {currentSeason === "Winter" && (
                          <>
                            <Badge variant="outline">Wheat</Badge>
                            <Badge variant="outline">Barley</Badge>
                            <Badge variant="outline">Mustard</Badge>
                            <Badge variant="outline">Peas</Badge>
                          </>
                        )}
                        {currentSeason === "Spring" && (
                          <>
                            <Badge variant="outline">Tomatoes</Badge>
                            <Badge variant="outline">Sunflower</Badge>
                            <Badge variant="outline">Okra</Badge>
                            <Badge variant="outline">Chilies</Badge>
                          </>
                        )}
                        {currentSeason === "Fall" && (
                          <>
                            <Badge variant="outline">Lentils</Badge>
                            <Badge variant="outline">Spinach</Badge>
                            <Badge variant="outline">Carrots</Badge>
                            <Badge variant="outline">Peas</Badge>
                          </>
                        )}
                      </div>
                    </div>
                    
                    <div className="border rounded-md p-3 bg-primary/5">
                      <h4 className="font-medium mb-2 text-sm flex items-center">
                        <CloudRain className="h-4 w-4 mr-2" />
                        Weather considerations:
                      </h4>
                      <p className="text-sm">{weatherData?.forecast || "Weather data not available. Check back later for personalized recommendations."}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Get Recommendations</CardTitle>
                  <CardDescription>
                    Tell us about your farm to get personalized crop recommendations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RecommendationForm />
                </CardContent>
              </Card>
            </div>
            
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Your Crop Planning</CardTitle>
                  <CardDescription>Manage your crops and recommendations</CardDescription>
                </CardHeader>
                
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 rounded-none border-b">
                    <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
                    <TabsTrigger value="my-crops">My Crops</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="recommendations" className="p-4">
                    {isLoadingRecommendations ? (
                      <div className="flex justify-center items-center h-48">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : recommendations.length === 0 ? (
                      <div className="text-center py-10">
                        <Sprout className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium">No recommendations yet</h3>
                        <p className="text-muted-foreground mt-2">
                          Fill out the form to get personalized crop recommendations
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {recommendations.map((recommendation) => (
                          <Card key={recommendation.id} className="overflow-hidden">
                            <div className="flex flex-col sm:flex-row">
                              <div className="sm:w-1/3 bg-primary/10 p-4 flex flex-col justify-center items-center text-center">
                                <h3 className="font-bold text-lg">{recommendation.cropName}</h3>
                                <Badge className="mt-2">{recommendation.suitabilityScore}% Match</Badge>
                                <Button variant="secondary" size="sm" className="mt-3">
                                  Add to My Crops
                                </Button>
                              </div>
                              <div className="sm:w-2/3 p-4">
                                <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
                                  <div>
                                    <span className="text-muted-foreground">Soil Type:</span>{" "}
                                    <span className="font-medium capitalize">{recommendation.soilType}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Water Needs:</span>{" "}
                                    <span className="font-medium">{recommendation.waterRequirements}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Growth Season:</span>{" "}
                                    <span className="font-medium">{recommendation.growingSeason}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Yield Potential:</span>{" "}
                                    <span className="font-medium">{recommendation.expectedYield}</span>
                                  </div>
                                </div>
                                <p className="text-sm">{recommendation.description}</p>
                                
                                <Separator className="my-3" />
                                
                                <div className="text-sm">
                                  <span className="text-xs font-medium text-muted-foreground">Weather Compatibility:</span>
                                  <div className="flex items-center mt-1 gap-2">
                                    <Progress value={
                                      weatherData?.condition?.toLowerCase().includes(recommendation.growingSeason.toLowerCase()) 
                                        ? 90 
                                        : currentSeason === recommendation.growingSeason 
                                          ? 75 
                                          : 40
                                    } className="h-1.5 flex-1" />
                                    <span className="text-xs">
                                      {weatherData?.condition?.toLowerCase().includes(recommendation.growingSeason.toLowerCase())
                                        ? "Excellent" 
                                        : currentSeason === recommendation.growingSeason 
                                          ? "Good" 
                                          : "Fair"}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="my-crops" className="p-4">
                    {isLoadingUserCrops ? (
                      <div className="flex justify-center items-center h-48">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : userCrops.length === 0 ? (
                      <div className="text-center py-10">
                        <Sprout className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium">No crops added yet</h3>
                        <p className="text-muted-foreground mt-2">
                          Add recommendations to your crop list to track and manage them
                        </p>
                        <Button 
                          variant="default" 
                          className="mt-4"
                          onClick={() => setActiveTab("recommendations")}
                        >
                          Browse Recommendations
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {userCrops.map((crop) => (
                          <Card key={crop.id} className="overflow-hidden">
                            <div className="flex flex-col sm:flex-row">
                              <div className="sm:w-1/3 bg-primary/10 p-4 flex flex-col justify-center items-center text-center">
                                <h3 className="font-bold text-lg">{crop.cropName}</h3>
                                <Badge className="mt-2">{crop.status || "Planned"}</Badge>
                              </div>
                              <div className="sm:w-2/3 p-4">
                                <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
                                  <div>
                                    <span className="text-muted-foreground">Planting Date:</span>{" "}
                                    <span className="font-medium">{crop.plantingDate || "Not set"}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Expected Harvest:</span>{" "}
                                    <span className="font-medium">{crop.harvestDate || "Not set"}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Area Planted:</span>{" "}
                                    <span className="font-medium">{crop.area || "Not set"}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Expected Yield:</span>{" "}
                                    <span className="font-medium">{crop.expectedYield}</span>
                                  </div>
                                </div>
                                <p className="text-sm">{crop.notes || crop.description}</p>
                                
                                <Separator className="my-3" />
                                
                                <div className="flex flex-wrap gap-2 mt-3">
                                  <Button variant="outline" size="sm">Update Status</Button>
                                  <Button variant="outline" size="sm">Add Notes</Button>
                                  <Button variant="outline" size="sm" className="text-red-500">Remove</Button>
                                </div>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </Card>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
