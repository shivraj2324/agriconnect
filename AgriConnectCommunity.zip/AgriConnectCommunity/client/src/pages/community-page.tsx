import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import ForumList from "@/components/community/forum-list";
import GroupList from "@/components/community/group-list";
import Chat from "@/components/community/chat";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ForumTopic, ForumGroup } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { queryClient } from "@/lib/queryClient";
import { 
  Loader2, 
  Users, 
  Send, 
  PlusCircle, 
  UserPlus, 
  MessageSquare, 
  Search, 
  Bell, 
  Settings2, 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical,
  CheckCheck, 
  Check, 
  Paperclip,
  Image,
  Smile
} from "lucide-react";
import { 
  Avatar, 
  AvatarFallback, 
  AvatarImage 
} from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger, 
  DialogClose 
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface Message {
  id: number;
  senderId: number;
  senderName: string;
  content: string;
  timestamp: string;
  read: boolean;
  attachment?: string;
}

interface ChatGroup {
  id: number;
  name: string;
  description: string;
  memberCount: number;
  avatar: string;
  lastMessage?: {
    content: string;
    timestamp: string;
  };
  messages: Message[];
  unreadCount: number;
  members: {
    id: number;
    name: string;
    avatar: string;
    status: string;
  }[];
}

export default function CommunityPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("whatsapp");
  const [activeWhatsAppTab, setActiveWhatsAppTab] = useState<string>("chats");
  const [selectedTopic, setSelectedTopic] = useState<ForumTopic | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<ForumGroup | null>(null);
  const [selectedChat, setSelectedChat] = useState<ChatGroup | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [newMessage, setNewMessage] = useState<string>("");
  const messageEndRef = useRef<HTMLDivElement>(null);
  
  const { data: topics = [], isLoading: isLoadingTopics } = useQuery<ForumTopic[]>({
    queryKey: ["/api/forum/topics"],
  });
  
  const { data: groups = [], isLoading: isLoadingGroups } = useQuery<ForumGroup[]>({
    queryKey: ["/api/forum/groups"],
  });
  
  // Reset selected items when changing tabs
  useEffect(() => {
    if (activeTab === "forum") {
      setSelectedChat(null);
      setSelectedGroup(null);
    } else if (activeTab === "groups") {
      setSelectedChat(null);
      setSelectedTopic(null);
    } else if (activeTab === "whatsapp") {
      setSelectedTopic(null);
      setSelectedGroup(null);
    }
  }, [activeTab]);

  // Mock data for WhatsApp-like chat groups
  const chatGroups: ChatGroup[] = [
    {
      id: 1,
      name: "Local Farmers Association",
      description: "A group for local farmers to share information and support",
      memberCount: 18,
      avatar: "",
      lastMessage: {
        content: "Does anyone have advice for dealing with the recent pest outbreak?",
        timestamp: "1h ago"
      },
      unreadCount: 3,
      messages: [
        {
          id: 1,
          senderId: 2,
          senderName: "Rahul Singh",
          content: "Has anyone tried the new organic pesticide?",
          timestamp: "11:30 AM",
          read: true
        },
        {
          id: 2,
          senderId: 3,
          senderName: "Amit Kumar",
          content: "Yes, it worked well for my tomato plants!",
          timestamp: "11:32 AM",
          read: true
        },
        {
          id: 3,
          senderId: 4,
          senderName: "Priya Sharma",
          content: "Where did you purchase it from? I'm looking for good solutions too.",
          timestamp: "11:40 AM",
          read: true,
        },
        {
          id: 4,
          senderId: 3,
          senderName: "Amit Kumar",
          content: "I got it from the agricultural supply store in town. They have a good selection of organic options now.",
          timestamp: "11:45 AM",
          read: true
        },
        {
          id: 5,
          senderId: 5,
          senderName: "Sanjay Patel",
          content: "Does anyone have advice for dealing with the recent pest outbreak?",
          timestamp: "12:15 PM",
          read: false
        }
      ],
      members: [
        { id: 1, name: "You", avatar: "", status: "online" },
        { id: 2, name: "Rahul Singh", avatar: "", status: "online" },
        { id: 3, name: "Amit Kumar", avatar: "", status: "away" },
        { id: 4, name: "Priya Sharma", avatar: "", status: "online" },
        { id: 5, name: "Sanjay Patel", avatar: "", status: "offline" }
      ]
    },
    {
      id: 2,
      name: "Crop Management Tips",
      description: "Discussions about optimizing crop yields and management techniques",
      memberCount: 32,
      avatar: "",
      lastMessage: {
        content: "I just posted a guide on rice irrigation techniques.",
        timestamp: "3h ago"
      },
      unreadCount: 0,
      messages: [
        {
          id: 1,
          senderId: 6,
          senderName: "Anita Desai",
          content: "Hello everyone! I've compiled a guide on optimal irrigation scheduling for rice crops.",
          timestamp: "10:15 AM",
          read: true
        },
        {
          id: 2,
          senderId: 7,
          senderName: "Vikram Mehta",
          content: "That sounds really helpful Anita! Would you mind sharing it here?",
          timestamp: "10:20 AM",
          read: true
        },
        {
          id: 3,
          senderId: 6,
          senderName: "Anita Desai",
          content: "Sure! I just posted a guide on rice irrigation techniques. It includes timing recommendations based on growth stages.",
          timestamp: "10:32 AM",
          read: true,
          attachment: "Rice_Irrigation_Guide.pdf"
        },
        {
          id: 4,
          senderId: 8,
          senderName: "Rajesh Kumar",
          content: "Thank you! This will be very useful for the upcoming season.",
          timestamp: "10:45 AM",
          read: true
        }
      ],
      members: [
        { id: 1, name: "You", avatar: "", status: "online" },
        { id: 6, name: "Anita Desai", avatar: "", status: "online" },
        { id: 7, name: "Vikram Mehta", avatar: "", status: "offline" },
        { id: 8, name: "Rajesh Kumar", avatar: "", status: "away" }
      ]
    },
    {
      id: 3,
      name: "Organic Farming Network",
      description: "For farmers practicing organic and sustainable farming methods",
      memberCount: 24,
      avatar: "",
      lastMessage: {
        content: "Has anyone had success with companion planting tomatoes and basil?",
        timestamp: "Yesterday"
      },
      unreadCount: 0,
      messages: [
        {
          id: 1,
          senderId: 9,
          senderName: "Meena Reddy",
          content: "Has anyone had success with companion planting tomatoes and basil?",
          timestamp: "Yesterday, 4:30 PM",
          read: true
        },
        {
          id: 2,
          senderId: 10,
          senderName: "Dinesh Joshi",
          content: "Yes, it works very well! The basil helps repel certain pests that attack tomatoes.",
          timestamp: "Yesterday, 4:40 PM",
          read: true
        },
        {
          id: 3,
          senderId: 11,
          senderName: "Lakshmi Nair",
          content: "I've been doing this for years. It also improves the flavor of the tomatoes, in my opinion.",
          timestamp: "Yesterday, 5:00 PM",
          read: true
        }
      ],
      members: [
        { id: 1, name: "You", avatar: "", status: "online" },
        { id: 9, name: "Meena Reddy", avatar: "", status: "offline" },
        { id: 10, name: "Dinesh Joshi", avatar: "", status: "away" },
        { id: 11, name: "Lakshmi Nair", avatar: "", status: "online" }
      ]
    }
  ];
  
  // Filter chat groups based on search query
  const filteredChatGroups = chatGroups.filter(group => 
    group.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    group.description.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleTopicSelect = (topic: ForumTopic) => {
    setSelectedTopic(topic);
    setSelectedGroup(null);
    setSelectedChat(null);
  };
  
  const handleGroupSelect = (group: ForumGroup) => {
    setSelectedGroup(group);
    setSelectedTopic(null);
    setSelectedChat(null);
  };
  
  const handleChatSelect = (chat: ChatGroup) => {
    setSelectedChat(chat);
    setSelectedTopic(null);
    setSelectedGroup(null);
  };
  
  const handleBackToList = () => {
    if (activeTab === "forum") {
      setSelectedTopic(null);
    } else if (activeTab === "groups") {
      setSelectedGroup(null);
    } else {
      setSelectedChat(null);
    }
  };

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedChat) return;
    
    const newMsg: Message = {
      id: selectedChat.messages.length + 1,
      senderId: 1, // Current user
      senderName: "You",
      content: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false
    };
    
    // Update the selected chat with the new message
    const updatedChat = {
      ...selectedChat,
      messages: [...selectedChat.messages, newMsg],
      lastMessage: {
        content: newMessage,
        timestamp: "Just now"
      }
    };
    
    setSelectedChat(updatedChat);
    setNewMessage("");
  };
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (messageEndRef.current) {
      messageEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedChat?.messages]);

  const getInitials = (name: string) => {
    if (!name) return "U";
    return name.split(" ").map(part => part[0]).join("").toUpperCase();
  };
  
  const formatInitials = (name: string) => {
    return name.split(" ").map(part => part[0]).join("").toUpperCase();
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="py-10 bg-neutral-50 flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-neutral-900">Farmer Community</h1>
            <p className="mt-2 text-lg text-neutral-500">
              Connect with other farmers, share knowledge, and join groups
            </p>
          </div>

          <Card className="mb-6">
            <CardHeader className="pb-0">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="whatsapp">Farmer Chat</TabsTrigger>
                  <TabsTrigger value="forum">Discussion Forums</TabsTrigger>
                  <TabsTrigger value="groups">Community Groups</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>
            <CardContent className="p-0 pt-4">
              {activeTab === "whatsapp" ? (
                selectedChat ? (
                  // WhatsApp-style chat interface
                  <div className="flex flex-col h-[75vh]">
                    {/* Chat header */}
                    <div className="border-b p-3 flex items-center justify-between bg-green-50">
                      <div className="flex items-center gap-3">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={handleBackToList}
                          className="md:hidden"
                        >
                          <ArrowLeft className="h-5 w-5" />
                        </Button>
                        <Avatar className="h-10 w-10 border border-neutral-200">
                          <AvatarFallback className="bg-green-100 text-green-700">
                            {formatInitials(selectedChat.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-medium">{selectedChat.name}</h3>
                          <p className="text-xs text-muted-foreground">
                            {selectedChat.memberCount} members • {selectedChat.members.filter(m => m.status === "online").length} online
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon">
                          <Phone className="h-5 w-5 text-green-600" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Video className="h-5 w-5 text-green-600" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Search className="h-5 w-5" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-5 w-5" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <UserPlus className="h-4 w-4 mr-2" />
                              Add member
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Bell className="h-4 w-4 mr-2" />
                              Mute notifications
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-500">
                              Leave group
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    
                    {/* Chat messages */}
                    <ScrollArea className="flex-1 p-4 bg-neutral-50">
                      <div className="space-y-4">
                        {selectedChat.messages.map((message) => (
                          <div 
                            key={message.id} 
                            className={`flex ${message.senderId === 1 ? "justify-end" : "justify-start"}`}
                          >
                            <div 
                              className={`max-w-[80%] md:max-w-[60%] rounded-lg p-3 ${
                                message.senderId === 1 
                                  ? "bg-green-100 rounded-br-none" 
                                  : "bg-white rounded-bl-none border"
                              }`}
                            >
                              {message.senderId !== 1 && (
                                <p className="text-xs font-medium text-green-700 mb-1">{message.senderName}</p>
                              )}
                              <p className="text-sm">{message.content}</p>
                              {message.attachment && (
                                <div className="mt-2 p-2 bg-white rounded border flex items-center gap-2">
                                  <Paperclip className="h-4 w-4 text-blue-500" />
                                  <span className="text-xs text-blue-500 font-medium">{message.attachment}</span>
                                </div>
                              )}
                              <div className="flex items-center justify-end gap-1 mt-1">
                                <span className="text-[10px] text-neutral-500">{message.timestamp}</span>
                                {message.senderId === 1 && (
                                  <div className="text-[10px]">
                                    {message.read ? (
                                      <CheckCheck className="h-3 w-3 text-blue-500" />
                                    ) : (
                                      <Check className="h-3 w-3 text-neutral-400" />
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                        <div ref={messageEndRef} />
                      </div>
                    </ScrollArea>
                    
                    {/* Chat input */}
                    <div className="p-3 flex items-center gap-2 border-t bg-white">
                      <Button variant="ghost" size="icon">
                        <Smile className="h-5 w-5 text-green-600" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Paperclip className="h-5 w-5 text-green-600" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Image className="h-5 w-5 text-green-600" />
                      </Button>
                      <Input 
                        placeholder="Type a message" 
                        className="flex-1"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                      />
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim()}
                      >
                        <Send className={`h-5 w-5 ${newMessage.trim() ? "text-green-600" : "text-neutral-400"}`} />
                      </Button>
                    </div>
                  </div>
                ) : (
                  // WhatsApp-style chat list
                  <div className="h-[75vh] flex">
                    {/* Sidebar */}
                    <div className="w-full lg:w-1/3 border-r">
                      <div className="bg-green-50 p-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback className="bg-green-600 text-white">
                              {user ? getInitials(user.firstName || user.username) : "U"}
                            </AvatarFallback>
                          </Avatar>
                          <h3 className="font-medium">Farmer Chat</h3>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="icon">
                            <Settings2 className="h-5 w-5" />
                          </Button>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <PlusCircle className="h-5 w-5" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Create a New Group</DialogTitle>
                                <DialogDescription>
                                  Create a new group to connect with other farmers.
                                </DialogDescription>
                              </DialogHeader>
                              <div className="grid gap-4 py-4">
                                <div className="grid gap-2">
                                  <Label htmlFor="group-name">Group Name</Label>
                                  <Input id="group-name" placeholder="E.g., Organic Farmers Network" />
                                </div>
                                <div className="grid gap-2">
                                  <Label htmlFor="group-description">Description</Label>
                                  <Textarea id="group-description" placeholder="What is this group about?" />
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">Cancel</Button>
                                </DialogClose>
                                <Button type="submit">Create Group</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                      
                      <div className="p-3 border-b">
                        <div className="relative">
                          <Search className="h-4 w-4 absolute left-3 top-3 text-neutral-400" />
                          <Input 
                            placeholder="Search or start a new chat" 
                            className="pl-10"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                          />
                        </div>
                      </div>
                      
                      <Tabs value={activeWhatsAppTab} onValueChange={setActiveWhatsAppTab} className="w-full">
                        <TabsList className="grid w-full grid-cols-2 rounded-none border-b">
                          <TabsTrigger value="chats">Chats</TabsTrigger>
                          <TabsTrigger value="contacts">Contacts</TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="chats" className="p-0 m-0">
                          <ScrollArea className="h-[60vh]">
                            {filteredChatGroups.map((chat) => (
                              <div 
                                key={chat.id}
                                className="p-3 border-b hover:bg-neutral-50 cursor-pointer"
                                onClick={() => handleChatSelect(chat)}
                              >
                                <div className="flex items-center gap-3">
                                  <Avatar className="h-12 w-12 border border-neutral-200">
                                    <AvatarFallback className="bg-green-100 text-green-700">
                                      {formatInitials(chat.name)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between">
                                      <h4 className="font-medium truncate">{chat.name}</h4>
                                      <span className="text-xs text-neutral-500">{chat.lastMessage?.timestamp}</span>
                                    </div>
                                    <p className="text-sm text-neutral-500 truncate">
                                      {chat.lastMessage?.content}
                                    </p>
                                  </div>
                                  {chat.unreadCount > 0 && (
                                    <Badge className="rounded-full bg-green-500">
                                      {chat.unreadCount}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            ))}
                          </ScrollArea>
                        </TabsContent>
                        
                        <TabsContent value="contacts" className="p-0 m-0">
                          <ScrollArea className="h-[60vh]">
                            <div className="p-6 text-center">
                              <Users className="h-12 w-12 mx-auto text-neutral-300 mb-2" />
                              <h4 className="font-medium">Your Contacts</h4>
                              <p className="text-sm text-neutral-500 mt-1">
                                Find and connect with other farmers
                              </p>
                              <Button className="mt-4">
                                <UserPlus className="h-4 w-4 mr-2" />
                                Add New Contact
                              </Button>
                            </div>
                          </ScrollArea>
                        </TabsContent>
                      </Tabs>
                    </div>
                    
                    {/* Empty state for chat content */}
                    <div className="hidden lg:flex flex-col items-center justify-center w-2/3 bg-neutral-50">
                      <MessageSquare className="h-16 w-16 text-neutral-300 mb-4" />
                      <h2 className="text-xl font-medium mb-2">Welcome to Farmer Chat</h2>
                      <p className="text-neutral-500 text-center max-w-md">
                        Connect with other farmers, share knowledge, and build your farming community. 
                        Select a chat to start messaging.
                      </p>
                    </div>
                  </div>
                )
              ) : activeTab === "forum" ? (
                selectedTopic ? (
                  <Chat 
                    topic={selectedTopic} 
                    onBack={handleBackToList} 
                  />
                ) : (
                  <ForumList 
                    topics={topics} 
                    isLoading={isLoadingTopics}
                    onSelectTopic={handleTopicSelect} 
                  />
                )
              ) : (
                selectedGroup ? (
                  <Chat 
                    group={selectedGroup} 
                    onBack={handleBackToList} 
                  />
                ) : (
                  <GroupList 
                    groups={groups} 
                    isLoading={isLoadingGroups}
                    onSelectGroup={handleGroupSelect} 
                  />
                )
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
