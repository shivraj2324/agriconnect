import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users Schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  region: text("region"),
});

export const insertUserSchema = createInsertSchema(users);
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Products Schema
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  price: doublePrecision("price").notNull(),
  quantity: doublePrecision("quantity").notNull(),
  unit: text("unit").notNull(),
  category: text("category").notNull(),
});

export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// Forum Topics Schema
export const forumTopics = pgTable("forum_topics", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  authorId: integer("author_id").notNull(),
  author: text("author").notNull(),
  createdAt: text("created_at").notNull(),
  upvotes: integer("upvotes").default(0),
  tags: text("tags").array(),
});

export const insertForumTopicSchema = createInsertSchema(forumTopics).omit({ id: true });
export type InsertForumTopic = z.infer<typeof insertForumTopicSchema>;
export type ForumTopic = typeof forumTopics.$inferSelect & {
  replies?: number[];
  saved?: boolean;
};

// Forum Replies Schema
export const forumReplies = pgTable("forum_replies", {
  id: serial("id").primaryKey(),
  topicId: integer("topic_id").notNull(),
  content: text("content").notNull(),
  authorId: integer("author_id").notNull(),
  author: text("author").notNull(),
  createdAt: text("created_at").notNull(),
  upvotes: integer("upvotes").default(0),
});

export const insertForumReplySchema = createInsertSchema(forumReplies).omit({ id: true });
export type InsertForumReply = z.infer<typeof insertForumReplySchema>;
export type ForumReply = typeof forumReplies.$inferSelect & {
  upvoted?: boolean;
};

// Forum Groups Schema
export const forumGroups = pgTable("forum_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  memberCount: integer("member_count").default(0),
  activityLevel: text("activity_level"),
});

export type ForumGroup = typeof forumGroups.$inferSelect & {
  isMember?: boolean;
};

// Forum Group Members Schema
export const forumGroupMembers = pgTable("forum_group_members", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  userId: integer("user_id").notNull(),
  joinedAt: timestamp("joined_at").notNull(),
});

// Forum Group Messages Schema
export const forumGroupMessages = pgTable("forum_group_messages", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  content: text("content").notNull(),
  authorId: integer("author_id").notNull(),
  author: text("author").notNull(),
  createdAt: text("created_at").notNull(),
});

export const insertForumMessageSchema = createInsertSchema(forumGroupMessages).omit({ id: true });
export type InsertForumMessage = z.infer<typeof insertForumMessageSchema>;
export type ForumMessage = typeof forumGroupMessages.$inferSelect;

// Articles Schema
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  summary: text("summary"),
  author: text("author"),
  publishedAt: text("published_at").notNull(),
  category: text("category").notNull(),
  tags: text("tags").array(),
  imageUrl: text("image_url"),
  source: text("source").default("internal"),
  sourceUrl: text("source_url"),
});

export type Article = typeof articles.$inferSelect;

// Crop Recommendations Schema
export const cropRecommendations = pgTable("crop_recommendations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  cropName: text("crop_name").notNull(),
  soilType: text("soil_type").notNull(),
  suitabilityScore: integer("suitability_score").notNull(),
  waterRequirements: text("water_requirements").notNull(),
  growingSeason: text("growing_season").notNull(),
  expectedYield: text("expected_yield").notNull(),
  description: text("description"),
  status: text("status"),
  plantingDate: text("planting_date"),
  harvestDate: text("harvest_date"),
  area: text("area"),
  notes: text("notes"),
});

export const insertCropRecommendationSchema = createInsertSchema(cropRecommendations).omit({ id: true });
export type InsertCropRecommendation = z.infer<typeof insertCropRecommendationSchema>;
export type CropRecommendation = typeof cropRecommendations.$inferSelect;

// User Crops Schema
export const userCrops = pgTable("user_crops", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  cropName: text("crop_name").notNull(),
  status: text("status").notNull(),
  plantingDate: text("planting_date"),
  harvestDate: text("harvest_date"),
  area: text("area"),
  soilType: text("soil_type"),
  waterRequirements: text("water_requirements"),
  expectedYield: text("expected_yield"),
  notes: text("notes"),
  description: text("description"),
});

export const insertUserCropSchema = createInsertSchema(userCrops).omit({ id: true });
export type InsertUserCrop = z.infer<typeof insertUserCropSchema>;
export type UserCrop = typeof userCrops.$inferSelect;
