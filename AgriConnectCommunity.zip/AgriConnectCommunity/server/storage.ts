import { 
  users, type User, type InsertUser,
  products, type Product, type InsertProduct,
  forumTopics, type ForumTopic, type InsertForumTopic,
  forumReplies, type ForumReply, type InsertForumReply,
  forumGroups, type ForumGroup,
  forumGroupMembers,
  forumGroupMessages, type ForumMessage, type InsertForumMessage,
  articles, type Article,
  cropRecommendations, type CropRecommendation, type InsertCropRecommendation,
  userCrops, type UserCrop, type InsertUserCrop
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Products management
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByUserId(userId: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<Product>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;
  
  // Forum topics management
  getForumTopics(): Promise<ForumTopic[]>;
  createForumTopic(topic: InsertForumTopic): Promise<ForumTopic>;
  getTopicReplies(topicId: number): Promise<ForumReply[]>;
  createTopicReply(reply: InsertForumReply): Promise<ForumReply>;
  upvoteTopicReply(replyId: number, userId: number): Promise<ForumReply>;
  
  // Forum groups management
  getForumGroups(userId: number | null): Promise<ForumGroup[]>;
  joinForumGroup(groupId: number, userId: number): Promise<ForumGroup>;
  getGroupMessages(groupId: number): Promise<ForumMessage[]>;
  createGroupMessage(message: InsertForumMessage): Promise<ForumMessage>;
  
  // Articles management
  getArticles(): Promise<Article[]>;
  
  // Crop recommendations management
  getCropRecommendations(userId: number): Promise<CropRecommendation[]>;
  createCropRecommendation(recommendation: InsertCropRecommendation): Promise<CropRecommendation>;
  getUserCrops(userId: number): Promise<UserCrop[]>;
  createUserCrop(crop: InsertUserCrop): Promise<UserCrop>;
  
  // Session management
  sessionStore: any;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private forumTopics: Map<number, ForumTopic>;
  private forumReplies: Map<number, ForumReply>;
  private forumReplyUpvotes: Map<string, boolean>; // `${replyId}-${userId}`
  private forumGroups: Map<number, ForumGroup>;
  private forumGroupMembers: Set<string>; // `${groupId}-${userId}`
  private forumMessages: Map<number, ForumMessage>;
  private articles: Map<number, Article>;
  private cropRecommendations: Map<number, CropRecommendation>;
  private userCrops: Map<number, UserCrop>;
  
  sessionStore: any;
  
  private currentId: {
    [key: string]: number;
  };

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.forumTopics = new Map();
    this.forumReplies = new Map();
    this.forumReplyUpvotes = new Map();
    this.forumGroups = new Map();
    this.forumGroupMembers = new Set();
    this.forumMessages = new Map();
    this.articles = new Map();
    this.cropRecommendations = new Map();
    this.userCrops = new Map();
    
    this.currentId = {
      user: 1,
      product: 1,
      forumTopic: 1,
      forumReply: 1,
      forumGroup: 1,
      forumMessage: 1,
      article: 1,
      cropRecommendation: 1,
      userCrop: 1
    };
    
    // Initialize session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    // Initialize sample data
    this.initData();
  }

  // User Methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.user++;
    const user: User = { 
      id, 
      username: insertUser.username,
      password: insertUser.password,
      email: insertUser.email || null,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      region: insertUser.region || null
    };
    this.users.set(id, user);
    return user;
  }
  
  // Product Methods
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductsByUserId(userId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.userId === userId
    );
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentId.product++;
    const product: Product = { 
      id,
      userId: insertProduct.userId,
      name: insertProduct.name,
      price: insertProduct.price,
      quantity: insertProduct.quantity,
      unit: insertProduct.unit,
      category: insertProduct.category,
      description: insertProduct.description || null
    };
    this.products.set(id, product);
    return product;
  }
  
  async updateProduct(id: number, productData: Partial<Product>): Promise<Product> {
    const existingProduct = this.products.get(id);
    if (!existingProduct) {
      throw new Error("Product not found");
    }
    
    const updatedProduct = { ...existingProduct, ...productData };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<void> {
    this.products.delete(id);
  }
  
  // Forum Topic Methods
  async getForumTopics(): Promise<ForumTopic[]> {
    return Array.from(this.forumTopics.values());
  }
  
  async createForumTopic(insertTopic: InsertForumTopic): Promise<ForumTopic> {
    const id = this.currentId.forumTopic++;
    const topic: ForumTopic = { 
      id,
      title: insertTopic.title,
      content: insertTopic.content,
      authorId: insertTopic.authorId,
      author: insertTopic.author,
      createdAt: insertTopic.createdAt,
      upvotes: 0,
      tags: insertTopic.tags || null,
      replies: [],
      saved: false
    };
    this.forumTopics.set(id, topic);
    return topic;
  }
  
  async getTopicReplies(topicId: number): Promise<ForumReply[]> {
    return Array.from(this.forumReplies.values()).filter(
      (reply) => reply.topicId === topicId
    );
  }
  
  async createTopicReply(insertReply: InsertForumReply): Promise<ForumReply> {
    const id = this.currentId.forumReply++;
    const reply: ForumReply = { 
      ...insertReply, 
      id,
      upvotes: 0,
      upvoted: false
    };
    this.forumReplies.set(id, reply);
    
    // Update topic with reply reference
    const topic = this.forumTopics.get(reply.topicId);
    if (topic) {
      const updatedTopic = { 
        ...topic, 
        replies: [...(topic.replies || []), id] 
      };
      this.forumTopics.set(topic.id, updatedTopic);
    }
    
    return reply;
  }
  
  async upvoteTopicReply(replyId: number, userId: number): Promise<ForumReply> {
    const reply = this.forumReplies.get(replyId);
    if (!reply) {
      throw new Error("Reply not found");
    }
    
    const upvoteKey = `${replyId}-${userId}`;
    const hasUpvoted = this.forumReplyUpvotes.has(upvoteKey);
    const currentUpvotes = reply.upvotes || 0;
    
    if (hasUpvoted) {
      // Remove upvote
      this.forumReplyUpvotes.delete(upvoteKey);
      const updatedReply = { 
        ...reply, 
        upvotes: currentUpvotes - 1,
        upvoted: false
      };
      this.forumReplies.set(replyId, updatedReply);
      return updatedReply;
    } else {
      // Add upvote
      this.forumReplyUpvotes.set(upvoteKey, true);
      const updatedReply = { 
        ...reply, 
        upvotes: currentUpvotes + 1,
        upvoted: true
      };
      this.forumReplies.set(replyId, updatedReply);
      return updatedReply;
    }
  }
  
  // Forum Group Methods
  async getForumGroups(userId: number | null): Promise<ForumGroup[]> {
    const groups = Array.from(this.forumGroups.values());
    
    if (userId) {
      // Mark groups the user is a member of
      return groups.map(group => ({
        ...group,
        isMember: this.forumGroupMembers.has(`${group.id}-${userId}`)
      }));
    }
    
    return groups;
  }
  
  async joinForumGroup(groupId: number, userId: number): Promise<ForumGroup> {
    const group = this.forumGroups.get(groupId);
    if (!group) {
      throw new Error("Group not found");
    }
    
    const memberKey = `${groupId}-${userId}`;
    this.forumGroupMembers.add(memberKey);
    
    // Update member count
    const currentMemberCount = group.memberCount || 0;
    const updatedGroup = { 
      ...group, 
      memberCount: currentMemberCount + 1,
      isMember: true
    };
    this.forumGroups.set(groupId, updatedGroup);
    
    return updatedGroup;
  }
  
  async getGroupMessages(groupId: number): Promise<ForumMessage[]> {
    return Array.from(this.forumMessages.values()).filter(
      (message) => message.groupId === groupId
    );
  }
  
  async createGroupMessage(insertMessage: InsertForumMessage): Promise<ForumMessage> {
    const id = this.currentId.forumMessage++;
    const message: ForumMessage = { ...insertMessage, id };
    this.forumMessages.set(id, message);
    return message;
  }
  
  // Articles Methods
  async getArticles(): Promise<Article[]> {
    return Array.from(this.articles.values());
  }
  
  // Crop Recommendation Methods
  async getCropRecommendations(userId: number): Promise<CropRecommendation[]> {
    return Array.from(this.cropRecommendations.values()).filter(
      (recommendation) => recommendation.userId === userId
    );
  }
  
  async createCropRecommendation(insertRecommendation: InsertCropRecommendation): Promise<CropRecommendation> {
    const id = this.currentId.cropRecommendation++;
    const recommendation: CropRecommendation = { 
      id,
      userId: insertRecommendation.userId,
      cropName: insertRecommendation.cropName,
      soilType: insertRecommendation.soilType,
      suitabilityScore: insertRecommendation.suitabilityScore,
      waterRequirements: insertRecommendation.waterRequirements,
      growingSeason: insertRecommendation.growingSeason,
      expectedYield: insertRecommendation.expectedYield,
      plantingDate: insertRecommendation.plantingDate || null,
      harvestDate: insertRecommendation.harvestDate || null,
      description: insertRecommendation.description || null,
      status: insertRecommendation.status || null,
      area: insertRecommendation.area || null,
      notes: insertRecommendation.notes || null
    };
    this.cropRecommendations.set(id, recommendation);
    return recommendation;
  }
  
  async getUserCrops(userId: number): Promise<UserCrop[]> {
    return Array.from(this.userCrops.values()).filter(
      (crop) => crop.userId === userId
    );
  }
  
  async createUserCrop(insertCrop: InsertUserCrop): Promise<UserCrop> {
    const id = this.currentId.userCrop++;
    const crop: UserCrop = {
      id,
      userId: insertCrop.userId,
      cropName: insertCrop.cropName,
      status: insertCrop.status,
      description: insertCrop.description || null,
      soilType: insertCrop.soilType || null,
      waterRequirements: insertCrop.waterRequirements || null,
      expectedYield: insertCrop.expectedYield || null,
      plantingDate: insertCrop.plantingDate || null,
      harvestDate: insertCrop.harvestDate || null,
      area: insertCrop.area || null,
      notes: insertCrop.notes || null
    };
    this.userCrops.set(id, crop);
    return crop;
  }
  
  // Initialize sample data
  private initData() {
    // Create sample forum groups
    const sampleGroups: ForumGroup[] = [
      {
        id: this.currentId.forumGroup++,
        name: "Organic Farming",
        description: "Discussions on organic farming techniques, certification, and marketing organic produce.",
        category: "Organic Farming",
        memberCount: 243,
        activityLevel: "Very active",
        isMember: false
      },
      {
        id: this.currentId.forumGroup++,
        name: "Modern Techniques",
        description: "Discussing the latest farming technology, machinery, and modern agricultural practices.",
        category: "Modern Techniques",
        memberCount: 198,
        activityLevel: "Active",
        isMember: false
      },
      {
        id: this.currentId.forumGroup++,
        name: "Weather & Climate",
        description: "For discussions on weather patterns, climate change impacts, and adaptation strategies.",
        category: "Weather & Climate",
        memberCount: 312,
        activityLevel: "Very active",
        isMember: false
      }
    ];
    
    sampleGroups.forEach(group => this.forumGroups.set(group.id, group));
    
    // Create sample articles
    const sampleArticles: Article[] = [
      {
        id: this.currentId.article++,
        title: "Sustainable Farming Practices for Small Holders",
        content: "Sustainable farming practices are essential for small-scale farmers to maximize productivity while preserving natural resources. This article explores key techniques such as crop rotation, companion planting, and natural pest control methods.\n\nCrop rotation involves changing the crops grown in a specific area each season. This helps to break pest cycles, improve soil health, and reduce the need for chemical fertilizers.\n\nCompanion planting is another effective technique, where certain plants are grown together because they benefit each other. For example, marigolds repel many harmful insects and can be planted alongside vegetables to protect them.\n\nNatural pest control methods, such as introducing beneficial insects or using neem oil, can be environmentally friendly alternatives to chemical pesticides. Integrated Pest Management (IPM) strategies help farmers make informed decisions about pest control, minimizing environmental impact and cost.\n\nImplementing sustainable water management through technologies like drip irrigation can significantly reduce water usage while ensuring crops receive adequate moisture. Mulching can also help to conserve soil moisture and suppress weeds.\n\nFinally, maintaining good soil health through composting and the application of organic matter is fundamental to sustainable farming. Healthy soil leads to healthier plants with better natural resistance to pests and diseases.",
        category: "Sustainable Farming",
        tags: ["organic", "sustainable", "small-scale", "techniques"],
        author: "Dr. Avinash Kumar",
        publishedAt: "2023-05-15T08:00:00Z",
        summary: "Learn about effective sustainable farming practices that small-scale farmers can implement to improve productivity while protecting the environment.",
        source: "internal",
        sourceUrl: null,
        imageUrl: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1932&q=80"
      },
      {
        id: this.currentId.article++,
        title: "Climate-Smart Agriculture: Adapting to Changing Weather Patterns",
        content: "Climate change is creating new challenges for farmers worldwide, with unpredictable weather patterns affecting traditional growing seasons. Climate-smart agriculture (CSA) offers solutions to help farmers adapt to these changing conditions.\n\nCSA focuses on three main pillars: sustainably increasing agricultural productivity and incomes; adapting and building resilience to climate change; and reducing greenhouse gas emissions where possible.\n\nOne key strategy is the use of drought-resistant crop varieties that can withstand longer dry periods. Researchers have developed varieties of staple crops like rice, wheat, and maize that require less water while maintaining good yields.\n\nWater harvesting techniques, such as constructing small check dams or contour trenches, help capture rainfall and reduce runoff, making more water available during dry periods.\n\nAgroforestry, which integrates trees with crop production, provides multiple benefits. Trees provide shade, reduce soil erosion, improve soil fertility, and can offer additional income sources through fruits, nuts, or timber.\n\nTiming of planting is becoming increasingly critical as traditional seasons shift. Many farmers are now using seasonal climate forecasts to determine optimal planting times.\n\nDiversifying crops is another effective strategy, as it spreads risk. If one crop fails due to adverse weather conditions, others might survive and provide income.\n\nImplementing these climate-smart approaches requires access to information, technologies, and sometimes initial investment. However, the long-term benefits in terms of improved resilience and sustainable production make these approaches essential for modern agriculture.",
        category: "Climate Change",
        tags: ["climate-smart", "adaptation", "resilience", "drought-resistant"],
        author: "Dr. Nandini Sharma",
        publishedAt: "2023-06-22T10:00:00Z",
        summary: "Discover how climate-smart agriculture techniques can help farmers adapt to changing weather patterns and build resilience against climate change impacts.",
        source: "internal",
        sourceUrl: null,
        imageUrl: "https://images.unsplash.com/photo-1473873430135-74d04d89c414?ixlib=rb-1.2.1&auto=format&fit=crop&w=1932&q=80"
      },
      {
        id: this.currentId.article++,
        title: "Maximizing Profits with Strategic Crop Selection",
        content: "Selecting the right crops to grow is one of the most important decisions a farmer makes, directly impacting profitability. This article provides guidance on strategic crop selection to maximize farm income.\n\nMarket analysis should be your starting point. Identify crops with strong demand and good price trends. Consider both local markets and export opportunities if applicable. Understanding market cycles can help you time your production for better prices.\n\nAssess your farm's specific conditions, including soil type, water availability, climate, and topography. Different crops thrive in different environments, and choosing crops well-suited to your conditions reduces input costs and increases yields.\n\nConsider your available resources, including equipment, labor, storage facilities, and capital. Some high-value crops require significant investment in specialized equipment or have high labor requirements.\n\nRisk management is essential. Diversifying with multiple crops can protect against price fluctuations and crop failures. Consider including both staple crops with stable markets and high-value specialty crops.\n\nRotation benefits should factor into your decisions. Some crops improve soil health or break pest cycles when used in rotation. A well-planned rotation can reduce input costs for subsequent crops.\n\nFinally, consider your personal expertise and interest. Crops that you have experience with or are particularly passionate about often perform better on your farm.\n\nBy taking a strategic approach to crop selection that balances market opportunities, farm conditions, available resources, risk management, rotation benefits, and personal factors, you can significantly improve your farm's profitability and sustainability.",
        category: "Farm Management",
        tags: ["crop selection", "profitability", "market analysis", "farm planning"],
        author: "Rajesh Patel",
        publishedAt: "2023-04-10T09:30:00Z",
        summary: "Learn strategic approaches to selecting crops that will maximize your farm's profitability while managing risks and maintaining soil health.",
        source: "external",
        sourceUrl: "https://www.agribusiness-insight.com/articles/crop-selection",
        imageUrl: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?ixlib=rb-1.2.1&auto=format&fit=crop&w=1932&q=80"
      },
      {
        id: this.currentId.article++,
        title: "Integrated Pest Management: Reducing Chemical Dependence",
        content: "Integrated Pest Management (IPM) is a holistic approach to pest control that minimizes environmental impact while effectively managing crop pests. This approach reduces dependence on chemical pesticides, which can be costly and potentially harmful to beneficial organisms, the environment, and human health.\n\nThe foundation of IPM is monitoring and identification. Regularly scouting fields to identify pests present and their population levels allows for informed decision-making about when intervention is necessary. Understanding pest biology and lifecycle is crucial for targeting control measures effectively.\n\nIPM emphasizes the use of economic thresholds – determining the pest population level at which the cost of damage exceeds the cost of control measures. This prevents unnecessary pesticide applications when pest populations are not economically threatening.\n\nCultural practices form the first line of defense in IPM. Crop rotation disrupts pest cycles, while adjusting planting dates can help crops avoid peak pest periods. Selecting resistant varieties and maintaining proper plant spacing and field sanitation are other effective cultural controls.\n\nBiological control involves preserving and enhancing natural enemies of pests. This includes beneficial insects like ladybugs, lacewings, and parasitic wasps that prey on harmful pests. Creating habitat for these beneficial organisms can naturally suppress pest populations.\n\nMechanical and physical controls, such as traps, barriers, or manual removal, provide direct protection with minimal environmental impact.\n\nWhen pesticides are necessary, IPM advocates selecting the most specific, least toxic options and applying them precisely when and where needed. Rotating pesticides with different modes of action helps prevent resistance development.\n\nBy integrating these various approaches into a comprehensive management strategy, farmers can effectively control pests while reducing costs, preserving beneficial organisms, and minimizing environmental impact.",
        category: "Pest Management",
        tags: ["IPM", "pest control", "biological control", "sustainable"],
        author: "Dr. Meena Verma",
        publishedAt: "2023-07-05T14:15:00Z",
        summary: "Discover how Integrated Pest Management strategies can effectively control crop pests while reducing dependency on chemical pesticides.",
        source: "internal",
        sourceUrl: null,
        imageUrl: "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1932&q=80"
      }
    ];
    
    sampleArticles.forEach(article => this.articles.set(article.id, article));
  }
}

import { DatabaseStorage } from "./db-storage";

export const storage = new DatabaseStorage();
