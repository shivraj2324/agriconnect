import { MongoClient, Db, Collection } from "mongodb";
import { User, InsertUser } from "@shared/schema";

// MongoDB connection string
// For local development, use localhost
// For production, this should be set as an environment variable
const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017";
const dbName = "agriconnect";

// Singleton pattern for MongoDB client
let client: MongoClient | null = null;
let db: Db | null = null;

// Collections
let usersCollection: Collection | null = null;

export async function connect() {
  if (!client) {
    client = new MongoClient(uri);
    try {
      await client.connect();
      console.log("Connected to MongoDB");
      db = client.db(dbName);
      
      // Initialize collections
      usersCollection = db.collection("users");
      
      // Create indexes for better performance
      await usersCollection.createIndex({ username: 1 }, { unique: true });
      await usersCollection.createIndex({ email: 1 }, { unique: true });
      
      console.log("MongoDB collections initialized");
    } catch (error) {
      console.error("Error connecting to MongoDB:", error);
      throw error;
    }
  }
  return { client, db };
}

export async function disconnect() {
  if (client) {
    await client.close();
    client = null;
    db = null;
    console.log("Disconnected from MongoDB");
  }
}

// User operations
export async function findUserById(id: number): Promise<User | null> {
  if (!usersCollection) await connect();
  return usersCollection?.findOne<User>({ id }) || null;
}

export async function findUserByUsername(username: string): Promise<User | null> {
  if (!usersCollection) await connect();
  return usersCollection?.findOne<User>({ username }) || null;
}

export async function createUser(userData: InsertUser): Promise<User> {
  if (!usersCollection) await connect();
  
  // Get the highest ID currently in the collection to generate a new ID
  const highestUser = await usersCollection?.find().sort({ id: -1 }).limit(1).toArray();
  const newId = highestUser && highestUser.length > 0 ? highestUser[0].id + 1 : 1;
  
  const newUser = {
    ...userData,
    id: newId,
    createdAt: new Date(),
  };
  
  await usersCollection?.insertOne(newUser);
  return newUser as User;
}

// Remove automatic connect on module load to prevent errors
// This will be called explicitly from routes.ts