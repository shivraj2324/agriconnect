import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import axios from "axios";
import { connect as connectMongoDB } from "./mongodb";

export async function registerRoutes(app: Express): Promise<Server> {
  // Note: MongoDB is not currently available in this environment
  // so we're using PostgreSQL for all data storage
  console.log('Using PostgreSQL for user authentication and data storage');
  console.log('MongoDB connection is disabled (MongoDB is not available on this system)');
  
  // Setup authentication routes
  setupAuth(app);
  
  // Initialize database with sample data
  await (storage as any).initializeData();

  const httpServer = createServer(app);

  // Setup WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Handle WebSocket connections
  wss.on('connection', (ws, req) => {
    console.log('WebSocket client connected');

    // Extract path from URL to determine chat room (topic or group)
    const url = new URL(req.url || '', 'http://localhost');
    const pathParts = url.pathname.split('/');
    const chatType = pathParts[2]; // 'topic' or 'group'
    const chatId = pathParts[3];

    if (chatType && chatId) {
      const roomName = `${chatType}-${chatId}`;
      
      // Store room info with the connection
      (ws as any).roomName = roomName;
      
      ws.on('message', (message) => {
        // Broadcast message to all clients in the same room
        wss.clients.forEach((client) => {
          if (client !== ws && client.readyState === WebSocket.OPEN && (client as any).roomName === roomName) {
            client.send(message);
          }
        });
      });
    }

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // API Routes
  // Products API
  app.get("/api/products", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const products = await storage.getProductsByUserId(req.user.id);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Error fetching products" });
    }
  });

  app.post("/api/products", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const product = await storage.createProduct({
        ...req.body,
        userId: req.user.id
      });
      res.status(201).json(product);
    } catch (error) {
      res.status(500).json({ message: "Error creating product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const productId = parseInt(req.params.id);
    if (isNaN(productId)) {
      return res.status(400).json({ message: "Invalid product ID" });
    }
    
    try {
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      if (product.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedProduct = await storage.updateProduct(productId, req.body);
      res.json(updatedProduct);
    } catch (error) {
      res.status(500).json({ message: "Error updating product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const productId = parseInt(req.params.id);
    if (isNaN(productId)) {
      return res.status(400).json({ message: "Invalid product ID" });
    }
    
    try {
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      if (product.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      await storage.deleteProduct(productId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting product" });
    }
  });

  // Forum Topics API
  app.get("/api/forum/topics", async (req, res) => {
    try {
      const topics = await storage.getForumTopics();
      res.json(topics);
    } catch (error) {
      res.status(500).json({ message: "Error fetching forum topics" });
    }
  });

  app.post("/api/forum/topics", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const topic = await storage.createForumTopic({
        ...req.body,
        authorId: req.user.id,
        author: req.user.firstName ? `${req.user.firstName} ${req.user.lastName}` : req.user.username,
        createdAt: new Date().toISOString()
      });
      res.status(201).json(topic);
    } catch (error) {
      res.status(500).json({ message: "Error creating forum topic" });
    }
  });

  app.get("/api/forum/topics/:id/replies", async (req, res) => {
    const topicId = parseInt(req.params.id);
    if (isNaN(topicId)) {
      return res.status(400).json({ message: "Invalid topic ID" });
    }
    
    try {
      const replies = await storage.getTopicReplies(topicId);
      res.json(replies);
    } catch (error) {
      res.status(500).json({ message: "Error fetching replies" });
    }
  });

  app.post("/api/forum/topics/:id/replies", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const topicId = parseInt(req.params.id);
    if (isNaN(topicId)) {
      return res.status(400).json({ message: "Invalid topic ID" });
    }
    
    try {
      const reply = await storage.createTopicReply({
        ...req.body,
        topicId,
        authorId: req.user.id,
        author: req.user.firstName ? `${req.user.firstName} ${req.user.lastName}` : req.user.username,
        createdAt: new Date().toISOString()
      });
      res.status(201).json(reply);
    } catch (error) {
      res.status(500).json({ message: "Error creating reply" });
    }
  });

  app.post("/api/forum/topics/:topicId/replies/:replyId/upvote", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const topicId = parseInt(req.params.topicId);
    const replyId = parseInt(req.params.replyId);
    
    if (isNaN(topicId) || isNaN(replyId)) {
      return res.status(400).json({ message: "Invalid topic or reply ID" });
    }
    
    try {
      const updatedReply = await storage.upvoteTopicReply(replyId, req.user.id);
      res.json(updatedReply);
    } catch (error) {
      res.status(500).json({ message: "Error upvoting reply" });
    }
  });

  // Forum Groups API
  app.get("/api/forum/groups", async (req, res) => {
    try {
      const groups = await storage.getForumGroups(req.isAuthenticated() ? req.user.id : null);
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Error fetching forum groups" });
    }
  });

  app.post("/api/forum/groups/:id/join", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const groupId = parseInt(req.params.id);
    if (isNaN(groupId)) {
      return res.status(400).json({ message: "Invalid group ID" });
    }
    
    try {
      const group = await storage.joinForumGroup(groupId, req.user.id);
      res.json(group);
    } catch (error) {
      res.status(500).json({ message: "Error joining group" });
    }
  });

  app.get("/api/forum/groups/:id/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const groupId = parseInt(req.params.id);
    if (isNaN(groupId)) {
      return res.status(400).json({ message: "Invalid group ID" });
    }
    
    try {
      const messages = await storage.getGroupMessages(groupId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Error fetching messages" });
    }
  });

  app.post("/api/forum/groups/:id/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const groupId = parseInt(req.params.id);
    if (isNaN(groupId)) {
      return res.status(400).json({ message: "Invalid group ID" });
    }
    
    try {
      const message = await storage.createGroupMessage({
        ...req.body,
        groupId,
        authorId: req.user.id,
        author: req.user.firstName ? `${req.user.firstName} ${req.user.lastName}` : req.user.username,
        createdAt: new Date().toISOString()
      });
      res.status(201).json(message);
    } catch (error) {
      res.status(500).json({ message: "Error creating message" });
    }
  });

  // Articles API
  app.get("/api/articles", async (req, res) => {
    try {
      const articles = await storage.getArticles();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ message: "Error fetching articles" });
    }
  });

  // Weather API
  app.get("/api/weather", async (req, res) => {
    const { lat, lon } = req.query;
    
    try {
      // Use OpenWeatherMap API to get weather data
      const apiKey = process.env.OPENWEATHER_API_KEY || "demo_key";
      let locationQuery = "";
      
      if (lat && lon) {
        locationQuery = `lat=${lat}&lon=${lon}`;
      } else {
        // Default to Pune if no coordinates are provided
        locationQuery = "q=Pune,IN";
      }
      
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?${locationQuery}&units=metric&appid=${apiKey}`
      );
      
      const weatherData = {
        location: response.data.name + ", " + response.data.sys.country,
        temperature: Math.round(response.data.main.temp),
        condition: response.data.weather[0].main,
        icon: response.data.weather[0].icon,
        windSpeed: response.data.wind.speed,
        humidity: response.data.main.humidity,
        forecast: getForecastRecommendation(response.data.weather[0].main, response.data.main.temp)
      };
      
      res.json(weatherData);
    } catch (error) {
      // If API call fails, return dummy data
      console.error("Weather API error:", error);
      res.json({
        location: "Pune, Maharashtra",
        temperature: 32,
        condition: "Sunny",
        icon: "01d",
        windSpeed: 5,
        humidity: 45,
        forecast: "Good day for irrigation. Plan harvesting for early morning."
      });
    }
  });

  // Crop Recommendations API
  app.get("/api/crop-recommendations", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const recommendations = await storage.getCropRecommendations(req.user.id);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Error fetching crop recommendations" });
    }
  });

  app.post("/api/crop-recommendations", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      // Validate form data
      const schema = z.object({
        soilType: z.string(),
        rainfallLevel: z.string(),
        landSize: z.number(),
        temperature: z.string(),
        irrigationAccess: z.string(),
        farmingExperience: z.string()
      });
      
      const validatedData = schema.parse(req.body);
      
      // Generate recommendations based on input parameters
      const recommendations = generateCropRecommendations(validatedData);
      
      // Store recommendations
      for (const recommendation of recommendations) {
        await storage.createCropRecommendation({
          ...recommendation,
          userId: req.user.id
        });
      }
      
      res.status(201).json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Error generating crop recommendations" });
    }
  });

  app.get("/api/user-crops", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const crops = await storage.getUserCrops(req.user.id);
      res.json(crops);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user crops" });
    }
  });

  return httpServer;
}

// Helper function to generate a farming recommendation based on weather
function getForecastRecommendation(condition: string, temperature: number): string {
  const conditionLower = condition.toLowerCase();
  
  if (conditionLower.includes("rain") || conditionLower.includes("drizzle")) {
    return "Delay irrigation. Check fields for water drainage issues.";
  } else if (conditionLower.includes("clear") || conditionLower.includes("sun")) {
    if (temperature > 35) {
      return "Consider additional irrigation. Avoid midday field work due to heat.";
    } else if (temperature > 25) {
      return "Good day for irrigation. Plan harvesting for early morning.";
    } else {
      return "Ideal conditions for field work and planting activities.";
    }
  } else if (conditionLower.includes("cloud")) {
    return "Good conditions for transplanting and field work.";
  } else if (conditionLower.includes("storm") || conditionLower.includes("thunder")) {
    return "Secure equipment and livestock. Check fields after storm passes.";
  } else {
    return "Monitor conditions and plan field activities accordingly.";
  }
}

// Function to generate crop recommendations based on input parameters
function generateCropRecommendations(data: any) {
  // This would typically be a more complex algorithm with a database of crop requirements
  // Simplified version for demonstration purposes
  const cropDatabase = [
    {
      cropName: "Rice",
      soilTypes: ["loamy", "clay"],
      rainfallLevels: ["high", "medium"],
      temperaturePreference: ["warm", "hot"],
      waterRequirements: "High",
      description: "Staple grain crop suitable for water-abundant regions. Requires consistent flooding during growth phase.",
      expectedYield: "3-6 tons/hectare"
    },
    {
      cropName: "Wheat",
      soilTypes: ["loamy", "clay", "sandy"],
      rainfallLevels: ["medium", "low"],
      temperaturePreference: ["cool", "moderate"],
      waterRequirements: "Moderate",
      description: "Winter crop that thrives in well-drained soil with moderate moisture. Good rotation crop.",
      expectedYield: "2.5-4 tons/hectare"
    },
    {
      cropName: "Cotton",
      soilTypes: ["sandy", "loamy"],
      rainfallLevels: ["medium", "low"],
      temperaturePreference: ["warm", "hot"],
      waterRequirements: "Moderate",
      description: "Cash crop that requires warm conditions and moderate water. Sensitive to waterlogging.",
      expectedYield: "1.5-2.5 tons/hectare"
    },
    {
      cropName: "Maize (Corn)",
      soilTypes: ["loamy", "sandy"],
      rainfallLevels: ["medium"],
      temperaturePreference: ["moderate", "warm"],
      waterRequirements: "Moderate",
      description: "Versatile crop that grows well in warm conditions with good irrigation. High yield potential.",
      expectedYield: "4-7 tons/hectare"
    },
    {
      cropName: "Soybeans",
      soilTypes: ["loamy", "clay"],
      rainfallLevels: ["medium", "high"],
      temperaturePreference: ["moderate", "warm"],
      waterRequirements: "Moderate",
      description: "Nitrogen-fixing legume that improves soil health. Good rotation crop with cereals.",
      expectedYield: "2-3.5 tons/hectare"
    },
    {
      cropName: "Tomatoes",
      soilTypes: ["loamy", "sandy"],
      rainfallLevels: ["medium", "low"],
      temperaturePreference: ["moderate", "warm"],
      waterRequirements: "Moderate to High",
      description: "High-value vegetable crop that requires regular irrigation and warm conditions.",
      expectedYield: "25-80 tons/hectare"
    }
  ];

  // Calculate suitability scores and return recommendations
  const recommendations = cropDatabase.map(crop => {
    // Calculate a simple suitability score
    let score = 0;
    
    // Soil type match
    if (crop.soilTypes.includes(data.soilType)) {
      score += 25;
    }
    
    // Rainfall match
    if (crop.rainfallLevels.includes(data.rainfallLevel)) {
      score += 25;
    }
    
    // Temperature match
    if (crop.temperaturePreference.includes(data.temperature)) {
      score += 25;
    }
    
    // Irrigation match (if crop needs high water and farmer has good irrigation)
    if (crop.waterRequirements === "High" && ["good", "excellent"].includes(data.irrigationAccess)) {
      score += 25;
    } else if (crop.waterRequirements === "Moderate" && ["limited", "good", "excellent"].includes(data.irrigationAccess)) {
      score += 25;
    } else if (crop.waterRequirements === "Low") {
      score += 25;
    }
    
    // Calculate growing season based on temperature preference
    let growingSeason = "Year-round";
    if (crop.temperaturePreference.includes("cool")) {
      growingSeason = "Winter";
    } else if (crop.temperaturePreference.includes("hot")) {
      growingSeason = "Summer";
    } else if (crop.temperaturePreference.includes("moderate")) {
      growingSeason = "Spring/Fall";
    }
    
    return {
      cropName: crop.cropName,
      soilType: data.soilType,
      suitabilityScore: score,
      waterRequirements: crop.waterRequirements,
      growingSeason: growingSeason,
      expectedYield: crop.expectedYield,
      description: crop.description
    };
  });
  
  // Sort by suitability score (descending) and return top recommendations
  return recommendations
    .sort((a, b) => b.suitabilityScore - a.suitabilityScore)
    .slice(0, 3);
}
