import session from "express-session";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, sql } from "drizzle-orm";
import {
  users,
  products,
  forumTopics,
  forumReplies,
  forumGroups,
  forumGroupMembers,
  forumGroupMessages,
  articles,
  cropRecommendations,
  userCrops,
  
  User,
  Product,
  ForumTopic,
  ForumReply,
  ForumGroup,
  ForumMessage,
  Article,
  CropRecommendation,
  UserCrop,
  
  InsertUser,
  InsertProduct,
  InsertForumTopic,
  InsertForumReply,
  InsertForumMessage,
  InsertCropRecommendation,
  InsertUserCrop
} from "@shared/schema";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any to bypass type checking issues

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }
  
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }
  
  async getProductsByUserId(userId: number): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.userId, userId));
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db.insert(products).values(insertProduct).returning();
    return product;
  }
  
  async updateProduct(id: number, productData: Partial<Product>): Promise<Product> {
    const [updatedProduct] = await db
      .update(products)
      .set(productData)
      .where(eq(products.id, id))
      .returning();
    
    if (!updatedProduct) {
      throw new Error(`Product with ID ${id} not found`);
    }
    
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }
  
  async getForumTopics(): Promise<ForumTopic[]> {
    // Get all topics with their reply counts
    const topics = await db.select().from(forumTopics);
    
    // Get reply counts for each topic
    const replyCounts = await db
      .select({
        topicId: forumReplies.topicId,
        count: sql<number>`count(*)`.as('count')
      })
      .from(forumReplies)
      .groupBy(forumReplies.topicId);
    
    // Create a map of topic ID to reply count
    const replyCountMap = new Map();
    for (const { topicId, count } of replyCounts) {
      replyCountMap.set(topicId, count);
    }
    
    // Combine topics with their reply counts
    return topics.map(topic => ({
      ...topic,
      replies: [],
      saved: false
    }));
  }
  
  async createForumTopic(insertTopic: InsertForumTopic): Promise<ForumTopic> {
    const [topic] = await db.insert(forumTopics).values(insertTopic).returning();
    return {
      ...topic,
      replies: [],
      saved: false
    };
  }
  
  async getTopicReplies(topicId: number): Promise<ForumReply[]> {
    const replies = await db
      .select()
      .from(forumReplies)
      .where(eq(forumReplies.topicId, topicId));
    
    return replies.map(reply => ({
      ...reply,
      upvoted: false
    }));
  }
  
  async createTopicReply(insertReply: InsertForumReply): Promise<ForumReply> {
    const [reply] = await db
      .insert(forumReplies)
      .values(insertReply)
      .returning();
    
    return {
      ...reply,
      upvoted: false
    };
  }
  
  async upvoteTopicReply(replyId: number, userId: number): Promise<ForumReply> {
    // Update the upvote count
    const [updatedReply] = await db
      .update(forumReplies)
      .set({
        upvotes: sql`upvotes + 1`
      })
      .where(eq(forumReplies.id, replyId))
      .returning();
    
    if (!updatedReply) {
      throw new Error(`Reply with ID ${replyId} not found`);
    }
    
    return {
      ...updatedReply,
      upvoted: true
    };
  }
  
  async getForumGroups(userId: number | null): Promise<ForumGroup[]> {
    const groups = await db.select().from(forumGroups);
    
    if (!userId) {
      return groups.map(group => ({
        ...group,
        isMember: false
      }));
    }
    
    // Get the groups the user is a member of
    const membershipRecords = await db
      .select({ groupId: forumGroupMembers.groupId })
      .from(forumGroupMembers)
      .where(eq(forumGroupMembers.userId, userId));
    
    const membershipSet = new Set(membershipRecords.map(r => r.groupId));
    
    return groups.map(group => ({
      ...group,
      isMember: membershipSet.has(group.id)
    }));
  }
  
  async joinForumGroup(groupId: number, userId: number): Promise<ForumGroup> {
    // Check if user is already a member
    const [existingMembership] = await db
      .select()
      .from(forumGroupMembers)
      .where(
        and(
          eq(forumGroupMembers.groupId, groupId),
          eq(forumGroupMembers.userId, userId)
        )
      );
    
    if (!existingMembership) {
      // Add the user to the group
      await db.insert(forumGroupMembers).values({ 
        groupId, 
        userId, 
        joinedAt: new Date() 
      });
      
      // Increment the member count
      await db
        .update(forumGroups)
        .set({ memberCount: sql`member_count + 1` })
        .where(eq(forumGroups.id, groupId));
    }
    
    // Return the updated group
    const [group] = await db
      .select()
      .from(forumGroups)
      .where(eq(forumGroups.id, groupId));
    
    if (!group) {
      throw new Error(`Group with ID ${groupId} not found`);
    }
    
    return {
      ...group,
      isMember: true
    };
  }
  
  async getGroupMessages(groupId: number): Promise<ForumMessage[]> {
    return await db
      .select()
      .from(forumGroupMessages)
      .where(eq(forumGroupMessages.groupId, groupId))
      .orderBy(forumGroupMessages.createdAt);
  }
  
  async createGroupMessage(insertMessage: InsertForumMessage): Promise<ForumMessage> {
    const [message] = await db
      .insert(forumGroupMessages)
      .values(insertMessage)
      .returning();
    
    return message;
  }
  
  async getArticles(): Promise<Article[]> {
    return await db.select().from(articles);
  }
  
  async getCropRecommendations(userId: number): Promise<CropRecommendation[]> {
    return await db
      .select()
      .from(cropRecommendations)
      .where(eq(cropRecommendations.userId, userId));
  }
  
  async createCropRecommendation(insertRecommendation: InsertCropRecommendation): Promise<CropRecommendation> {
    const [recommendation] = await db
      .insert(cropRecommendations)
      .values(insertRecommendation)
      .returning();
    
    return recommendation;
  }
  
  async getUserCrops(userId: number): Promise<UserCrop[]> {
    return await db
      .select()
      .from(userCrops)
      .where(eq(userCrops.userId, userId));
  }
  
  async createUserCrop(insertCrop: InsertUserCrop): Promise<UserCrop> {
    const [crop] = await db
      .insert(userCrops)
      .values(insertCrop)
      .returning();
    
    return crop;
  }
  
  async initializeData() {
    // Check if we already have data
    const [articleCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(articles);
    
    if (articleCount.count > 0) {
      // Data already exists, no need to seed
      return;
    }
    
    // Sample forum groups
    const sampleGroups = [
      {
        name: "Rice Farmers",
        description: "Community for rice farmers to discuss best practices and share experiences",
        category: "Crop Specific",
        memberCount: 56,
        activityLevel: "Very Active"
      },
      {
        name: "Organic Farming",
        description: "Discussions around organic farming techniques and certification",
        category: "Farming Methods",
        memberCount: 124,
        activityLevel: "Active"
      },
      {
        name: "Agricultural Technology",
        description: "Exploring the latest technological innovations in farming",
        category: "Technology",
        memberCount: 89,
        activityLevel: "Moderate"
      }
    ];
    
    // Insert groups
    await db.insert(forumGroups).values(sampleGroups);
    
    // Sample articles
    const sampleArticles = [
      {
        title: "Sustainable Irrigation Methods for Water Conservation",
        content: "This comprehensive guide explores modern irrigation techniques that reduce water usage while maintaining crop health...",
        author: "Dr. Anjali Sharma",
        category: "Irrigation",
        tags: ["water-conservation", "sustainable-farming", "irrigation"],
        publishedAt: new Date().toISOString(),
        imageUrl: "https://images.unsplash.com/photo-1559486612-95ae499ae0df",
        summary: "Learn about water-saving irrigation methods that can help maintain crop yields while conserving vital water resources.",
        source: "internal",
        sourceUrl: null
      },
      {
        title: "Understanding Soil Health: A Beginner's Guide",
        content: "Learn the fundamentals of soil composition, testing methods, and how to improve soil health for better crop yields...",
        author: "Rajesh Patel",
        category: "Soil Management",
        tags: ["soil-health", "beginners-guide", "agriculture"],
        publishedAt: new Date().toISOString(),
        imageUrl: "https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad",
        summary: "Discover the basics of soil health and learn techniques to maintain optimal soil conditions for improved crop productivity.",
        source: "internal",
        sourceUrl: null
      },
      {
        title: "Pest Management Strategies for Organic Farms",
        content: "Discover effective natural methods to control pests without relying on chemical pesticides...",
        author: "Meena Reddy",
        category: "Pest Control",
        tags: ["organic-farming", "pest-management", "natural-methods"],
        publishedAt: new Date().toISOString(),
        imageUrl: "https://images.unsplash.com/photo-1635341814821-9d545c58949f",
        summary: "Explore organic approaches to pest control that maintain ecological balance while protecting your crops.",
        source: "internal",
        sourceUrl: null
      },
      {
        title: "Climate Resilient Farming: Adapting to Changing Weather Patterns",
        content: "This article discusses strategies for farmers to adapt their practices in response to climate change...",
        author: "Dr. Sanjay Kumar",
        category: "Climate Change",
        tags: ["climate-change", "resilience", "adaptation"],
        publishedAt: new Date().toISOString(),
        imageUrl: "https://images.unsplash.com/photo-1471193945509-9ad0617afabf",
        summary: "Learn how to make your farm more resilient to unpredictable weather patterns caused by climate change.",
        source: "internal",
        sourceUrl: null
      },
      {
        title: "Maximizing Profits with Strategic Crop Selection",
        content: "Learn how to analyze market trends and select the most profitable crops for your region...",
        author: "Priya Joshi",
        category: "Farm Economics",
        tags: ["profitability", "crop-selection", "market-analysis"],
        publishedAt: new Date().toISOString(),
        imageUrl: "https://images.unsplash.com/photo-1620200423727-8127f75d7f50",
        summary: "Discover how to choose crops that will maximize your farm's profitability based on market demand and local conditions.",
        source: "internal",
        sourceUrl: null
      }
    ];
    
    // Insert articles
    await db.insert(articles).values(sampleArticles);
  }
}