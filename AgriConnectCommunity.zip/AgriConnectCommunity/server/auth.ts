import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
// Import MongoDB functions but don't use them directly since MongoDB isn't available
import { findUserById, findUserByUsername, createUser } from "./mongodb";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "agriculture-connection-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax" as const
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Try to find user in PostgreSQL
        const pgUser = await storage.getUserByUsername(username);
        if (!pgUser || !(await comparePasswords(password, pgUser.password))) {
          // No user found in PostgreSQL, try MongoDB as a fallback
          try {
            const mongoUser = await findUserByUsername(username);
            if (mongoUser && await comparePasswords(password, mongoUser.password)) {
              return done(null, mongoUser);
            }
          } catch (mongoError) {
            // Ignore MongoDB errors
            console.log("MongoDB lookup failed, using PostgreSQL only");
          }
          
          return done(null, false);
        }
        
        return done(null, pgUser);
      } catch (error) {
        console.error("Login error:", error);
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      // Try to find user in PostgreSQL
      const pgUser = await storage.getUser(id);
      if (pgUser) {
        return done(null, pgUser);
      }
      
      // If not found in PostgreSQL, try MongoDB as a fallback
      try {
        const mongoUser = await findUserById(id);
        if (mongoUser) {
          return done(null, mongoUser);
        }
      } catch (mongoError) {
        // Ignore MongoDB errors
        console.log("MongoDB lookup failed, using PostgreSQL only");
      }
      
      // No user found
      done(null, null);
    } catch (error) {
      console.error("Session error:", error);
      done(error, null);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      // Check if user exists in PostgreSQL
      const pgUser = await storage.getUserByUsername(req.body.username);
      if (pgUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      // Create a hashed password
      const hashedPassword = await hashPassword(req.body.password);
      
      // Save user to PostgreSQL directly since MongoDB is unavailable
      console.log("Creating new user in PostgreSQL database");
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
      });

      req.login(user, (err) => {
        if (err) return next(err);
        
        // Don't send password to client
        const { password, ...userWithoutPassword } = user;
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      console.error("Registration error:", error);
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: Error | null, user: SelectUser | false, info: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ error: "Invalid credentials" });
      
      req.login(user, (err: Error | null) => {
        if (err) return next(err);
        
        // Don't send password to client
        const { password, ...userWithoutPassword } = user as SelectUser;
        res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    // First try to destroy the session
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          console.error("Error destroying session:", err);
          // Continue with standard logout even if session destruction fails
        }
        
        // Then logout the user
        req.logout((err) => {
          if (err) return next(err);
          
          // Clear cookie on client
          res.clearCookie('connect.sid');
          res.sendStatus(200);
        });
      });
    } else {
      // If no session exists, just logout
      req.logout((err) => {
        if (err) return next(err);
        res.sendStatus(200);
      });
    }
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // Don't send password to client
    const { password, ...userWithoutPassword } = req.user as SelectUser;
    res.json(userWithoutPassword);
  });
}
